<?php
// save_qam_state.php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Folder penyimpanan data
$file = __DIR__ . '/json_data/qam_last_state.json';

// Terima data JSON dari JavaScript
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if ($data) {
    // Simpan ke file json_data/qam_last_state.json
    if (file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT))) {
        echo json_encode(["status" => "success"]);
    } else {
        http_response_code(500);
        echo json_encode(["status" => "error", "msg" => "Gagal tulis file"]);
    }
} else {
    echo json_encode(["status" => "no_data"]);
}
?>