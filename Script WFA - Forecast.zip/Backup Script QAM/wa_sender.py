import time
import json
import os
import pyautogui
import pyperclip
import pygetwindow as gw
import sys
import subprocess
import glob

# --- 1. KONFIGURASI ---
BASE_DIR = r'F:\\'
QUEUE_DIR = os.path.join(BASE_DIR, 'json_queue') 
MESSAGE_BOX_IMAGE = os.path.join(BASE_DIR, 'web_assets', 'message_box.png')

# Kode Grup Dummy (Safety Zone)
DUMMY_GROUP_CODE = "BAjxgLakM8M83MtVjPh5Qk"

# --- 2. FUNGSI COPY (POWERSHELL) ---
def clip_files_robust(file_path):
    try:
        abs_path = os.path.normpath(os.path.abspath(file_path))
        ps_command = (f"powershell -command \"Add-Type -AssemblyName System.Windows.Forms; "
                      f"[System.Windows.Forms.Clipboard]::SetFileDropList([System.Collections.Specialized.StringCollection]@('{abs_path}'))\"")
        subprocess.run(ps_command, shell=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
        return True
    except: return False

# --- 3. NAVIGASI (WINDOW CONTROL) ---
def focus_whatsapp():
    try:
        windows = gw.getWindowsWithTitle('WhatsApp')
        if windows:
            win = windows[0]; 
            if win.isMinimized: win.restore(); 
            win.activate()
    except: pass

def minimize_whatsapp():
    """Meminimalkan jendela WhatsApp"""
    try:
        windows = gw.getWindowsWithTitle('WhatsApp')
        if windows:
            win = windows[0]
            if not win.isMinimized:
                win.minimize()
            print("[WIN] WhatsApp minimized.")
    except Exception as e:
        print(f"[ERR WIN] Gagal minimize: {e}")

def open_target_smart(target_val):
    """
    Membuka target tanpa Browser, langsung via Protokol WhatsApp.
    Logika deteksi: Panjang > 15 & Bukan Angka = Grup.
    """
    # print(f"[NAV] Raw Target: {target_val}") # Optional debug
    
    try:
        clean_code = target_val.strip()
        
        # PEMBERSIH: Jika user menyimpan Link Lengkap, ambil kodenya saja
        if "chat.whatsapp.com" in clean_code:
            clean_code = clean_code.split("/")[-1]
            
        url = ""
        
        # --- LOGIKA DETEKSI ---
        if len(clean_code) > 15 and not clean_code.isnumeric():
            # Asumsi Link Grup
            url = f"whatsapp://chat?code={clean_code}"
        else:
            # Asumsi Nomor HP
            phone = ''.join(filter(str.isdigit, clean_code))
            url = f"whatsapp://send?phone={phone}"

        # Eksekusi Protokol
        os.startfile(url)
        return True
    except Exception as e:
        print(f"[ERR NAV] {e}")
        return False

def wait_for_message_box(retries=10):
    print("   ...Mencari kotak pesan...")
    for i in range(retries):
        try:
            loc = pyautogui.locateOnScreen(MESSAGE_BOX_IMAGE, confidence=0.8, grayscale=True)
            if loc: return loc
        except: pass
        time.sleep(1)
    print("   [WARN] Blind Click Mode.")
    return None

# --- 4. PROSES UTAMA ---
def process_job(job):
    # 1. Buka Target (Smart Mode)
    open_target_smart(job['target_value'])
    
    print("[WAIT] Loading WhatsApp (6s)...")
    time.sleep(6) 
    focus_whatsapp()

    # 2. Klik Kotak Pesan
    box_loc = wait_for_message_box()
    if box_loc: pyautogui.click(box_loc)
    else: 
        sw, sh = pyautogui.size()
        pyautogui.click(sw/2, sh - 100)
    time.sleep(1)

    # 3. Kirim Konten
    msg = job.get('message', '')
    raw_attachment = job.get('attachment', None)
    success = False

    if raw_attachment and os.path.exists(raw_attachment):
        att = os.path.normpath(os.path.abspath(raw_attachment))
        print(f"[MEDIA] File: {os.path.basename(att)}")
        if clip_files_robust(att):
            time.sleep(1)
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(4) # Tunggu preview load
            if msg:
                pyperclip.copy(msg); time.sleep(0.5); pyautogui.hotkey('ctrl', 'v')
            time.sleep(1)
            pyautogui.press('enter')
            print("   [SENT] File terkirim.")
            success = True
        else: 
            success = False
    else:
        if not msg: return True # Job kosong dianggap selesai
        print("[TEXT] Mengirim teks...")
        pyperclip.copy(msg); time.sleep(0.5); pyautogui.hotkey('ctrl', 'v')
        time.sleep(0.5); pyautogui.press('enter')
        print("   [SENT] Teks terkirim.")
        success = True
    
    # 4. SAFETY LANDING (Masuk Grup Dummy & Minimize)
    if success:
        print("[SAFETY] Pindah ke Grup Dummy...")
        open_target_smart(DUMMY_GROUP_CODE)
        time.sleep(3) # Tunggu sebentar agar chat berpindah
        minimize_whatsapp()
        
    time.sleep(2)
    return success

# --- MAIN LOOP ---
print("=== WA ROBOT: SAFE MODE ===")
print(f"Pantau Folder: {QUEUE_DIR}")
print(f"Safety Group : {DUMMY_GROUP_CODE}")
print("-" * 50)

if not os.path.exists(QUEUE_DIR):
    try: os.makedirs(QUEUE_DIR)
    except: pass

spinner = ['|', '/', '-', '\\']
spin_idx = 0

while True:
    try:
        # Ambil tiket antrian (File JSON)
        files = glob.glob(os.path.join(QUEUE_DIR, "*.json"))
        
        if files:
            files.sort(key=os.path.getmtime) # FIFO
            target_file = files[0]

            sys.stdout.write('\r' + ' ' * 50 + '\r')
            print(f"[NEW JOB] File: {os.path.basename(target_file)}")

            try:
                with open(target_file, 'r') as f:
                    job = json.load(f)
            except:
                time.sleep(1); continue

            if process_job(job):
                try: os.remove(target_file)
                except: pass

                att = job.get('attachment')
                if att and os.path.exists(att):
                    try: os.remove(att)
                    except: pass
                
                print("[SLEEP] Cooldown 5s...")
                time.sleep(5)
            else:
                print("[RETRY] Gagal kirim.")
                time.sleep(10)

        else:
            sys.stdout.write(f"\r[IDLE] Menunggu antrian... {spinner[spin_idx]} ")
            sys.stdout.flush()
            spin_idx = (spin_idx + 1) % 4
            time.sleep(1)

    except KeyboardInterrupt:
        break
    except Exception as e:
        print(f"\n[ERROR LOOP] {e}")
        time.sleep(5)