<?php
// FILE: export.php
// Letakkan file ini satu folder dengan index.html

// Matikan batas waktu eksekusi agar tidak timeout saat memproses data tahunan
set_time_limit(0);
ini_set('memory_limit', '512M');

// --- 1. KONFIGURASI PATH ---
// Gunakan __DIR__ agar otomatis mendeteksi folder tempat file ini berada.
// Asumsinya folder "Data AWS AWOS" berada di sebelah file ini.
$base_path = __DIR__ . '/Data AWS AWOS/csv';

$files = [
    'aws'  => $base_path . '/aws_data.csv',
    'awos' => $base_path . '/awos_data.csv'
];

// --- 2. AMBIL DATA DARI REQUEST ---
$type  = isset($_GET['type']) ? $_GET['type'] : '';
$start = isset($_GET['start']) ? $_GET['start'] : '';
$end   = isset($_GET['end']) ? $_GET['end'] : '';

// Validasi Input
if (!isset($files[$type])) {
    die("Error: Tipe data tidak valid. Pilih 'aws' atau 'awos'.");
}

if (!file_exists($files[$type])) {
    die("Error: File CSV tidak ditemukan di: " . $files[$type] . "<br>Pastikan path folder benar.");
}

if (empty($start) || empty($end)) {
    die("Error: Tanggal mulai dan selesai harus diisi.");
}

// Nama file saat didownload
$filename = "Export_" . strtoupper($type) . "_" . str_replace([':', ' '], '-', $start) . "_sd_" . str_replace([':', ' '], '-', $end) . ".csv";

// --- 3. HEADER UNTUK DOWNLOAD ---
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Buka stream output (kirim langsung ke user)
$output = fopen('php://output', 'w');

// Buka file CSV sumber (mode baca)
$input = fopen($files[$type], 'r');

if ($input) {
    // Ambil baris pertama (Header: timestamp, temp, dll) dan tulis langsung
    $header = fgetcsv($input);
    if ($header) {
        fputcsv($output, $header);
    }

    // Konversi waktu request ke Timestamp Unix agar perbandingan lebih cepat
    $startTime = strtotime($start);
    $endTime   = strtotime($end);

    // --- 4. LOOPING DAN FILTER DATA ---
    // Kita baca baris per baris agar RAM server tidak penuh
    while (($row = fgetcsv($input)) !== false) {
        // Kolom 0 adalah timestamp (format: YYYY-MM-DD HH:MM:SS)
        if (isset($row[0])) {
            $rowTime = strtotime($row[0]);
            
            // Cek apakah waktu baris ini masuk dalam range yang diminta
            if ($rowTime >= $startTime && $rowTime <= $endTime) {
                fputcsv($output, $row);
            }
        }
    }
    fclose($input);
} else {
    echo "Gagal membuka file sumber.";
}

fclose($output);
exit;
?>