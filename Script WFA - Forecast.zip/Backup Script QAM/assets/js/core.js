// Inisialisasi Icon Lucide
lucide.createIcons();

// Jam Realtime
function updateClock() {
    const now = new Date();
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];
    const elDate = document.getElementById('top-date');
    const elClock = document.getElementById('top-clock');
    if (elDate && elClock) {
        elDate.innerText = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
        const h = (n) => String(n).padStart(2, '0');
        const timeWIT = `${h(now.getHours())}:${h(now.getMinutes())}:${h(now.getSeconds())}`;
        const timeUTC = `${h(now.getUTCHours())}:${h(now.getUTCMinutes())}:${h(now.getUTCSeconds())}`;
        elClock.innerHTML = `${timeWIT} <span class="text-sm font-bold text-slate-500">WIT</span> <span class="text-slate-300 mx-1">/</span> ${timeUTC} <span class="text-sm font-bold text-slate-500">UTC</span>`;
    }
}
setInterval(updateClock, 1000);
updateClock();

// Modal Image
function closeModal() {
    document.getElementById('imageModal').classList.add('hidden');
    document.getElementById('modalImage').src = "";
}

// --- BAGIAN INI YANG DIUPDATE ---
function switchTab(tabName) {
    const contentMain = document.getElementById('content-main');       // Halaman AWS/AWOS
    const contentBlank = document.getElementById('content-blank');     // Halaman Kosong
    const sectionQam = document.getElementById('section-qam');         // Halaman QAM
    const sectionForecast = document.getElementById('forecast-container'); // Halaman Forecast (BARU)
    const blankTitle = document.getElementById('blank-title');
    
    // 1. Reset Style Tombol Navigasi
    ['main', 'visibility', 'me48', 'forecast', 'qam'].forEach(btn => {
        const elBtn = document.getElementById('btn-' + btn);
        if(elBtn) {
            elBtn.className = "tab-inactive px-5 py-2 rounded-full font-bold text-sm transition-all cursor-pointer hover:bg-slate-200 text-slate-500";
        }
    });
    
    // Set tombol aktif
    const activeBtn = document.getElementById('btn-' + tabName);
    if(activeBtn) {
        activeBtn.className = "tab-active bg-blue-600 text-white shadow-md px-5 py-2 rounded-full font-bold text-sm transition-all cursor-pointer transform active:scale-95";
    }

    // 2. Sembunyikan SEMUA Konten dulu
    if(contentMain) contentMain.classList.add('hidden');
    if(contentBlank) contentBlank.classList.add('hidden');
    if(sectionQam) sectionQam.classList.add('hidden');
    if(sectionForecast) sectionForecast.classList.add('hidden'); // Sembunyikan forecast juga

    // 3. Tampilkan Konten sesuai Tab
    if (tabName === 'main') { 
        if(contentMain) contentMain.classList.remove('hidden'); 
    } 
    else if (tabName === 'qam') {
        if(sectionQam) sectionQam.classList.remove('hidden');
        if (typeof initQAMTab === 'function') initQAMTab();
    } 
    else if (tabName === 'forecast') {
        // --- LOGIKA BARU FORECAST ---
        if(sectionForecast) {
            sectionForecast.classList.remove('hidden');
            // Supaya tampilan canvas tidak blank saat baru dibuka:
            if (typeof drawForecast === 'function') {
                drawForecast(); 
            }
        }
    }
    else { 
        // Logic untuk halaman yang belum jadi (Visibility & ME48)
        if(contentBlank) contentBlank.classList.remove('hidden'); 
        if(blankTitle) blankTitle.innerText = {'visibility': 'Visibility Data', 'me48': 'ME48/45 Data'}[tabName]; 
    }
}