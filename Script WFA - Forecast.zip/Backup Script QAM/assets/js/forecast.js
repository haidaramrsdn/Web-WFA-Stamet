/**
 * ASSETS/JS/FORECAST.JS
 * Combined: Weather Forecast (Fixed) & Tide Forecast (Final)
 */

// ==========================================
// 1. WEATHER FORECAST LOGIC 
// ==========================================
const canvas = document.getElementById('forecastCanvas');
const ctx = canvas.getContext('2d');
const ASSET_PATH = 'web_assets/forecast/'; 

// Load Assets
const templateImg = new Image(); templateImg.src = ASSET_PATH + 'template_cuaca.jpg';
const coverImg = new Image(); coverImg.src = ASSET_PATH + 'template_cover_cuaca.jpg';

const iconImages = {};
const iconList = [
    'cerah', 'cerah_berawan', 'berawan', 'berawan_tebal', 
    'udara_kabur', 'kabut', 'hujan_ringan', 'hujan_sedang', 
    'hujan_lebat', 'hujan_petir', 'petir',
    'utara', 'timur_laut', 'timur', 'tenggara', 
    'selatan', 'barat_daya', 'barat', 'barat_laut'
];
iconList.forEach(name => { 
    const img = new Image(); 
    img.src = ASSET_PATH + name + '.png'; 
    iconImages[name] = img; 
});

const COORDS = {
    header_x: 140, header_y: 174, 
    warning_x: 151, warning_y: 1119, warning_width: 1050,
    row_start_y: 372, row_height: 83, 
    col_start_x: 225, col_step_x: 82, 
    temp_x: 975, rh_x: 1076, wind_x: 1178
};

function drawForecast() {
    // 1. Bersihkan & Gambar Background
    ctx.clearRect(0, 0, 1270, 1270);
    if (templateImg.complete) ctx.drawImage(templateImg, 0, 0, 1270, 1270);

    // 2. Header Tanggal
    const dateText = document.getElementById('fc_date') ? document.getElementById('fc_date').value : '';
    if(dateText) {
        ctx.font = "italic 600 26px 'Roboto', sans-serif"; 
        ctx.fillStyle = "white";
        ctx.textAlign = "left"; 
        ctx.textBaseline = "top"; 
        ctx.fillText(dateText, COORDS.header_x, COORDS.header_y);
    }
    
    ctx.textAlign = "center"; 
    ctx.textBaseline = "middle";

    // 3. Loop Icon Cuaca (Jam 09.00 - 09.00 Besok)
    const weatherSelects = document.querySelectorAll('.fc-weather');
    const colMap = {'09':0, '12':1, '15':2, '18':3, '21':4, '00':5, '03':6, '06':7, '09_besok':8};

    weatherSelects.forEach(select => {
        const val = select.value; 
        if (!val) return; 
        
        const distIndex = parseInt(select.getAttribute('data-district'));
        const colKey = select.getAttribute('data-col');
        const colIdx = colMap[colKey];

        const x = COORDS.col_start_x + (colIdx * COORDS.col_step_x);
        const y = COORDS.row_start_y + (distIndex * COORDS.row_height);

        if (iconImages[val]?.complete) {
            ctx.drawImage(iconImages[val], x - 27.5, y - 27.5, 55, 55); 
        }
    });

    // 4. Loop Data Angka & Angin Per Distrik
    for(let i=0; i<7; i++) {
        const y = COORDS.row_start_y + (i * COORDS.row_height);
        
        // Ambil Value dari Input
        const tMin = document.querySelector(`.fc-temp-min[data-district="${i}"]`).value;
        const tMax = document.querySelector(`.fc-temp-max[data-district="${i}"]`).value;
        const rMin = document.querySelector(`.fc-rh-min[data-district="${i}"]`).value;
        const rMax = document.querySelector(`.fc-rh-max[data-district="${i}"]`).value;
        const wDir = document.querySelector(`.fc-wind-dir[data-district="${i}"]`).value;
        const wSpd = document.querySelector(`.fc-wind-speed[data-district="${i}"]`).value;

        // Gambar Text Suhu & RH
        ctx.font = "400 24px 'Roboto', sans-serif"; 
        ctx.fillStyle = "white";
        ctx.fillText(`${tMin} - ${tMax}`, COORDS.temp_x, y);
        ctx.fillText(`${rMin} - ${rMax}`, COORDS.rh_x, y);

        // Gambar Simbol Angin
        if(wDir && iconImages[wDir]?.complete) {
            // Posisi Y dikoreksi agar pas ditengah (y - 20) karena ukuran gambar 40x40
            ctx.drawImage(iconImages[wDir], COORDS.wind_x - 20, y - 35, 40, 40);
        }

        // Gambar Kecepatan Angin
        if(wSpd) { 
            ctx.font = "400 22px 'Roboto', sans-serif"; 
            ctx.fillText(`${wSpd} Km/H`, COORDS.wind_x, y + 25); 
        }
    }
    
    // 5. Peringatan Dini
    const warningText = document.getElementById('fc_warning') ? document.getElementById('fc_warning').value : '';
    if (warningText) {
        ctx.font = "400 26px 'Roboto', sans-serif"; 
        ctx.fillStyle = "white"; 
        ctx.textAlign = "left"; 
        ctx.textBaseline = "top";
        wrapText(ctx, warningText, COORDS.warning_x, COORDS.warning_y, COORDS.warning_width, 35);
    }
}

// ==========================================
// 2. TIDE FORECAST LOGIC (SUDAH FINAL)
// ==========================================
const tideCanvas = document.getElementById('tideCanvas');
const tideCtx = tideCanvas.getContext('2d');
const templateTide1 = new Image(); templateTide1.src = ASSET_PATH + 'template_pasut_1hari.jpg';
const templateTide3 = new Image(); templateTide3.src = ASSET_PATH + 'template_pasut_3hari.jpg';
let currentTideMode = '1day';

function initTideDates() {
    const now = new Date();
    const tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1);
    const yyyy = tomorrow.getFullYear();
    const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
    const dd = String(tomorrow.getDate()).padStart(2, '0');
    const elDate = document.getElementById('tide_date_start');
    if(elDate) { elDate.value = `${yyyy}-${mm}-${dd}`; drawTide(); }
}

function switchTideMode(mode) {
    currentTideMode = mode;
    const btn1 = document.getElementById('btn-tide-1day');
    const btn3 = document.getElementById('btn-tide-3day');
    
    // Update Button Style
    if(mode === '1day') {
        btn1.className = "px-4 py-2 rounded-md text-sm font-bold transition-all bg-indigo-600 text-white shadow";
        btn3.className = "px-4 py-2 rounded-md text-sm font-bold transition-all text-slate-500 hover:bg-indigo-50";
        // Show/Hide Inputs
        document.querySelectorAll('.tide-input-1day').forEach(el => el.classList.remove('hidden'));
        document.querySelectorAll('.tide-input-3day-col1').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('.tide-input-3day-col2').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('.tide-input-3day-col3').forEach(el => el.classList.add('hidden'));
    } else {
        btn3.className = "px-4 py-2 rounded-md text-sm font-bold transition-all bg-indigo-600 text-white shadow";
        btn1.className = "px-4 py-2 rounded-md text-sm font-bold transition-all text-slate-500 hover:bg-indigo-50";
        // Show/Hide Inputs
        document.querySelectorAll('.tide-input-1day').forEach(el => el.classList.add('hidden'));
        document.querySelectorAll('.tide-input-3day-col1').forEach(el => el.classList.remove('hidden'));
        document.querySelectorAll('.tide-input-3day-col2').forEach(el => el.classList.remove('hidden'));
        document.querySelectorAll('.tide-input-3day-col3').forEach(el => el.classList.remove('hidden'));
    }
    drawTide();
}

function drawTide() {
    tideCtx.clearRect(0, 0, 1270, 1270);
    const bg = currentTideMode === '1day' ? templateTide1 : templateTide3;
    if (bg.complete) { tideCtx.drawImage(bg, 0, 0, 1270, 1270); } 
    else { setTimeout(drawTide, 500); return; }

    const startDateStr = document.getElementById('tide_date_start').value;
    if(!startDateStr) return;

    const d = new Date(startDateStr);
    const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    
    // Header Text
    tideCtx.fillStyle = "#FFFFFF"; 
    tideCtx.textAlign = "center"; 
    tideCtx.textBaseline = "top";

    if(currentTideMode === '1day') {
        tideCtx.font = "500 30px 'Roboto', sans-serif"; 
        const dayStr = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][d.getDay()];
        const dateText = `${dayStr}, ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
        tideCtx.fillText(dateText, 635, 220); 
    } 
    else {
        tideCtx.font = "500 30px 'Roboto', sans-serif"; 
        const dEnd = new Date(d); dEnd.setDate(d.getDate() + 2);
        const dateText = `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()} - ${dEnd.getDate()} ${months[dEnd.getMonth()]} ${dEnd.getFullYear()}`;
        tideCtx.fillText(dateText, 635, 221);
        
        tideCtx.font = "500 16px 'Roboto', sans-serif";
        tideCtx.textAlign = "center";
        
        for(let i=0; i<3; i++) {
            const loopDate = new Date(d); loopDate.setDate(d.getDate() + i);
            const shortMon = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'][loopDate.getMonth()];
            const headerStr = `${loopDate.getDate()} ${shortMon}`;
            const x = [153, 206, 262][i];
            
            tideCtx.fillStyle = "#FFFFFF"; 
            tideCtx.fillText(headerStr, x, 325);
        }
    }

    drawTideGraphCore(d);
}

function drawTideGraphCore(startDate) {
    let zone;
    if (currentTideMode === '1day') {
        zone = { x: 303, y: 352, w: 905, h: 707 };
    } else {
        zone = { x: 333, y: 350, w: 875, h: 713 };
    }

    const padL = 60, padB = 60, padT = 30, padR = 20;
    const plotX = zone.x + padL;
    const plotY = zone.y + padT;
    const plotW = zone.w - padL - padR;
    const plotH = zone.h - padB - padT;

    let datasets = [];
    let allValues = []; 

    if (currentTideMode === '1day') {
        let data = [];
        document.querySelectorAll('.tide-input-1day').forEach(el => {
            const val = parseFloat(el.value);
            if (!isNaN(val)) {
                data.push({ hour: parseInt(el.dataset.hour), val: val });
                allValues.push(val);
            }
        });
        datasets.push({ color: '#2563eb', data: data, label: 'Hari Ini' });
    } 
    else {
        const colors = ['#ef4444', '#eab308', '#22c55e'];
        for(let i=0; i<3; i++) {
            let data = [];
            document.querySelectorAll(`.tide-input-3day-col${i+1}`).forEach(el => {
                const val = parseFloat(el.value);
                if (!isNaN(val)) {
                    data.push({ hour: parseInt(el.dataset.hour), val: val });
                    allValues.push(val);
                }
            });
            const loopDate = new Date(startDate); loopDate.setDate(startDate.getDate() + i);
            const shortMon = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agt','Sep','Okt','Nov','Des'][loopDate.getMonth()];
            datasets.push({ color: colors[i], data: data, label: `${loopDate.getDate()} ${shortMon}` });
        }
    }

    if (allValues.length === 0) allValues = [0, 1];

    const dataMin = Math.min(...allValues);
    const dataMax = Math.max(...allValues);
    const range = dataMax - dataMin;
    const buffer = (range === 0) ? 0.5 : range * 0.1;
    
    const rawMinY = Math.floor((dataMin - buffer) * 10) / 10;
    const minY = rawMinY < 0 ? 0 : rawMinY;
    const maxY = Math.ceil((dataMax + buffer) * 10) / 10;
    const scaleRange = maxY - minY;

    const getX = (hour) => plotX + (hour / 23) * plotW; 
    const getY = (val) => plotY + plotH - ((val - minY) / scaleRange) * plotH;

    tideCtx.save();
    
    // Frame
    tideCtx.fillStyle = "rgba(255, 255, 255, 0.5)"; 
    tideCtx.fillRect(plotX, plotY, plotW, plotH);
    tideCtx.strokeStyle = "#334155";
    tideCtx.lineWidth = 1;
    tideCtx.strokeRect(plotX, plotY, plotW, plotH);

    // GRID Y
    tideCtx.fillStyle = "#000000"; 
    tideCtx.font = "bold 15px 'Roboto', sans-serif"; 
    tideCtx.textAlign = "right";
    tideCtx.textBaseline = "middle";
    
    const stepsY = 5; 
    for(let i=0; i<=stepsY; i++) {
        const val = minY + (scaleRange * (i / stepsY));
        const py = plotY + plotH - (plotH * (i / stepsY));
        
        tideCtx.beginPath();
        tideCtx.strokeStyle = "rgba(0,0,0,0.1)";
        tideCtx.moveTo(plotX, py);
        tideCtx.lineTo(plotX + plotW, py);
        tideCtx.stroke();

        tideCtx.fillText(val.toFixed(1), plotX - 10, py);
    }

    // GRID X
    tideCtx.textAlign = "center";
    tideCtx.textBaseline = "top";
    tideCtx.font = "bold 14px 'Roboto', sans-serif"; 
    
    for(let h=0; h<=23; h++) {
        const px = getX(h);
        tideCtx.beginPath();
        tideCtx.strokeStyle = "rgba(0,0,0,0.05)"; 
        tideCtx.moveTo(px, plotY);
        tideCtx.lineTo(px, plotY + plotH);
        tideCtx.stroke();
        tideCtx.fillText(String(h+1).padStart(2, '0'), px, plotY + plotH + 8);
    }

    // Titles
    tideCtx.font = "bold 18px 'Roboto', sans-serif"; 
    tideCtx.fillStyle = "#000000";
    tideCtx.textAlign = "center";
    tideCtx.fillText("Jam (WIT)", plotX + plotW/2, plotY + plotH + 40);

    tideCtx.save();
    tideCtx.translate(plotX - 50, plotY + plotH/2);
    tideCtx.rotate(-Math.PI / 2);
    tideCtx.textAlign = "center";
    tideCtx.fillText("Ketinggian (m)", 0, 0);
    tideCtx.restore();

    // Lines & Dots
    datasets.forEach(ds => {
        if(ds.data.length === 0) return;
        
        tideCtx.beginPath();
        tideCtx.lineWidth = 3;
        tideCtx.strokeStyle = ds.color;
        tideCtx.lineJoin = 'round';
        ds.data.sort((a,b) => a.hour - b.hour);
        ds.data.forEach((pt, idx) => {
            const px = getX(pt.hour);
            const py = getY(pt.val);
            if (idx === 0) tideCtx.moveTo(px, py);
            else tideCtx.lineTo(px, py);
        });
        tideCtx.stroke();

        tideCtx.font = "bold 14px 'Roboto', sans-serif"; 
        
        ds.data.forEach(pt => {
            const px = getX(pt.hour);
            const py = getY(pt.val);
            tideCtx.beginPath();
            tideCtx.fillStyle = ds.color;
            tideCtx.arc(px, py, 4, 0, Math.PI * 2);
            tideCtx.fill();

            tideCtx.fillStyle = "#000000";
            tideCtx.textAlign = "center";
            tideCtx.fillText(pt.val.toFixed(1), px, py - 15);
        });
    });

    // Legend
    if(datasets.length > 0 && currentTideMode === '3day') {
        let legX = plotX + plotW - 20; 
        let legY = plotY + 20;
        
        tideCtx.font = "bold 15px 'Roboto', sans-serif"; 
        tideCtx.textAlign = "right";
        tideCtx.textBaseline = "middle";

        const boxH = datasets.length * 25 + 10;
        tideCtx.fillStyle = "rgba(255, 255, 255, 0.9)";
        tideCtx.fillRect(legX - 120, legY - 10, 130, boxH);
        tideCtx.strokeStyle = "#ccc";
        tideCtx.strokeRect(legX - 120, legY - 10, 130, boxH);

        datasets.forEach(ds => {
            tideCtx.fillStyle = ds.color;
            tideCtx.fillRect(legX, legY - 5, 12, 12);
            tideCtx.fillStyle = "#000000";
            tideCtx.fillText(ds.label, legX - 8, legY);
            legY += 25;
        });
    }

    tideCtx.restore();
}

// ==========================================
// 3. SHARED HELPERS & INIT
// ==========================================

function downloadAll() {
    const elStart = document.getElementById('date_start');
    const dateFile = elStart && elStart.value ? elStart.value.slice(0,10) : 'Forecast';

    const linkForecast = document.createElement('a');
    linkForecast.download = `02_Prakiraan_Kaimana_${dateFile}.jpg`;
    linkForecast.href = canvas.toDataURL('image/jpeg', 1.0);
    linkForecast.click();

    setTimeout(() => {
        generateCoverDataURL((coverUrl) => {
            const linkCover = document.createElement('a');
            linkCover.download = `01_Cover_Kaimana_${dateFile}.jpg`;
            linkCover.href = coverUrl;
            linkCover.click();
        });
    }, 500);
}

function downloadTide() {
    const link = document.createElement('a');
    link.download = `Tide_Forecast_${currentTideMode}.jpg`;
    link.href = tideCanvas.toDataURL('image/jpeg', 1.0);
    link.click();
}

function generateCoverDataURL(callback) {
    const coverCanvas = document.createElement('canvas');
    coverCanvas.width = coverImg.width || 1270;
    coverCanvas.height = coverImg.height || 1270;
    const cCtx = coverCanvas.getContext('2d');

    if (coverImg.complete) {
        cCtx.drawImage(coverImg, 0, 0);
        cCtx.font = "600 48px 'Montserrat', sans-serif";
        cCtx.fillStyle = "white";
        cCtx.textAlign = "center";
        cCtx.textBaseline = "middle";
        const dateStr = canvas.getAttribute('data-cover-date') || "Senin, 01 Januari 2026";
        cCtx.fillText(dateStr, 641, 735);
        callback(coverCanvas.toDataURL('image/jpeg', 1.0));
    } else {
        alert("Gambar template cover belum termuat sempurna.");
    }
}

function wrapText(context, text, x, y, maxWidth, lineHeight) {
    var words = text.split(' '); var line = '';
    for(var n = 0; n < words.length; n++) {
        var testLine = line + words[n] + ' ';
        if (context.measureText(testLine).width > maxWidth && n > 0) {
            context.fillText(line, x, y); line = words[n] + ' '; y += lineHeight;
        } else { line = testLine; }
    }
    context.fillText(line, x, y);
}

function generateHeader() {
    const startVal = document.getElementById('date_start').value;
    const endVal = document.getElementById('date_end').value;
    if (!startVal || !endVal) return;
    const getIndo = (dStr) => {
        const d = new Date(dStr);
        const days = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
        const m = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
        const h = String(d.getHours()).padStart(2, '0'); const mn = String(d.getMinutes()).padStart(2, '0');
        return `${days[d.getDay()]}, ${d.getDate()} ${m[d.getMonth()]} ${d.getFullYear()} (${h}.${mn} WIT)`;
    };
    document.getElementById('fc_date').value = `Berlaku ${getIndo(startVal)} - ${getIndo(endVal)}`;
    if(typeof canvas !== 'undefined') canvas.setAttribute('data-cover-date', getIndo(startVal).split('(')[0].trim());
    drawForecast(); 
}

function setDefaultDates() {
    const now = new Date();
    const start = new Date(now); start.setDate(now.getDate() + 1); start.setHours(9,0,0,0);
    const end = new Date(start); end.setDate(start.getDate() + 1);
    const toISO = (d) => {
        const pad = (n) => String(n).padStart(2,'0');
        return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    };
    const elS = document.getElementById('date_start'); const elE = document.getElementById('date_end');
    if(elS && elE) { elS.value = toISO(start); elE.value = toISO(end); generateHeader(); }
}

// Initial Calls
templateImg.onload = drawForecast;
templateTide1.onload = drawTide;

setTimeout(() => {
    setDefaultDates();
    initTideDates(); 
}, 1000);

// --- BAGIAN INI YANG DIPERBAIKI (EVENT LISTENER LENGKAP) ---
document.addEventListener('input', function(e) {
    if(e.target.closest('#forecast-container')) {
        // Cek semua jenis input Weather Forecast
        if (
            e.target.classList.contains('fc-weather') || 
            e.target.classList.contains('fc-temp-min') || 
            e.target.classList.contains('fc-temp-max') || 
            e.target.classList.contains('fc-rh-min') || 
            e.target.classList.contains('fc-rh-max') || 
            e.target.classList.contains('fc-wind-dir') || 
            e.target.classList.contains('fc-wind-speed') || 
            e.target.id === 'fc_warning'
        ) {
            drawForecast();
        } 
        // Cek input Tide Forecast
        else if (e.target.classList.contains('pasut-input') || e.target.id === 'tide_date_start') {
            drawTide();
        }
    }
});