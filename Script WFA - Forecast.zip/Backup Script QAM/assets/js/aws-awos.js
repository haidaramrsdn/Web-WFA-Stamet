// --- VARIABEL GLOBAL AWS & AWOS ---
let historyAWS = [], historyAWOS = [];
let indexAWS = 0, indexAWOS = 0;
let manualModeAWS = false, manualModeAWOS = false;
let tempLatestAWS = null;
let tempLatestAWOS = null;

// Penanda agar history berat hanya diload sekali
let isHistoryLoaded = false; 

// --- FUNGSI PENGAMBIL DATA UTAMA ---
async function fetchAllData() {
    const ts = new Date().getTime(); 

    // 1. FETCH AWS LATEST (Tetap jalan tiap 3 detik)
    try {
        const r1 = await fetch('json_data/aws_latest.json?v=' + ts, { cache: "no-store" });
        if(r1.ok) {
            const latestAWS = await r1.json();
            
            // Cek apakah data ini baru dibandingkan data terakhir di history?
            // Jika ya, tambahkan ke historyAWS paling depan (Update Memory)
            if (historyAWS.length > 0) {
                const lastTime = historyAWS[0].timestamp;
                if (latestAWS.timestamp !== lastTime) {
                    historyAWS.unshift(latestAWS); // Masukkan data baru ke antrian history
                    // Opsional: Batasi agar browser tidak keberatan (misal simpan 2880 data / 2 hari)
                    if(historyAWS.length > 2880) historyAWS.pop(); 
                }
            } else {
                // Jika history kosong (belum keload), jadikan ini data pertama
                historyAWS = [latestAWS];
            }
            
            tempLatestAWS = latestAWS;

            // Render hanya jika user sedang melihat data paling depan (Live Mode)
            if (!manualModeAWS && indexAWS === 0) renderData('aws'); 
        }
    } catch(e) { console.log("Gagal load latest AWS"); }

    // 2. FETCH AWOS LATEST (Tetap jalan tiap 3 detik)
    try {
        const r2 = await fetch('json_data/awos_latest.json?v=' + ts, { cache: "no-store" });
        if(r2.ok) {
            const latestAWOS = await r2.json();

            // Logika Update Memory History AWOS
            if (historyAWOS.length > 0) {
                const lastTime = historyAWOS[0].timestamp;
                if (latestAWOS.timestamp !== lastTime) {
                    historyAWOS.unshift(latestAWOS);
                    if(historyAWOS.length > 2880) historyAWOS.pop();
                }
            } else {
                historyAWOS = [latestAWOS];
            }

            tempLatestAWOS = latestAWOS; 
            
            if (!manualModeAWOS && indexAWOS === 0) renderData('awos'); 
        }
    } catch(e) { console.log("Gagal load latest AWOS"); }

    // 3. JALANKAN BACKGROUND HISTORY (HANYA SEKALI SAJA DI AWAL)
    // Ini kunci agar Multi-Tab lancar & Server tidak macet
    if (!isHistoryLoaded) {
        loadHistoryInBackground(ts);
    }
}

async function loadHistoryInBackground(ts) {
    let successAWS = false;
    let successAWOS = false;

    // AWS HISTORY - Download file besar
    try {
        // Hapus {cache: "no-store"} untuk history agar browser boleh menyimpannya sebentar
        const r1 = await fetch('json_data/aws_history.json?v=' + ts);
        if(r1.ok) {
            const d1 = await r1.json();
            if(d1 && d1.length > 0) { 
                // Gabungkan kecerdasan: Data Latest di memory + Data History dari file
                if (historyAWS.length > 0) {
                    // Jika di memory sudah ada data latest, gabungkan dengan history file
                    // Filter d1 agar tidak ada duplikat dengan yang sudah ada di historyAWS
                    const currentLatestTime = historyAWS[0].timestamp;
                    const filteredHistory = d1.filter(item => item.timestamp < currentLatestTime);
                    historyAWS = historyAWS.concat(filteredHistory);
                } else {
                    historyAWS = d1;
                }
                
                // Refresh tampilan jika perlu
                if(!manualModeAWS && indexAWS === 0) renderData('aws'); 
                successAWS = true;
            }
        }
    } catch(e){}

    // AWOS HISTORY
    try {
        const r2 = await fetch('json_data/awos_history.json?v=' + ts);
        if(r2.ok) {
            const d2 = await r2.json();
            if(d2 && d2.length > 0) { 
                if (historyAWOS.length > 0) {
                    const currentLatestTime = historyAWOS[0].timestamp;
                    const filteredHistory = d2.filter(item => item.timestamp < currentLatestTime);
                    historyAWOS = historyAWOS.concat(filteredHistory);
                } else {
                    historyAWOS = d2;
                }

                if(!manualModeAWOS && indexAWOS === 0) renderData('awos'); 
                successAWOS = true;
            }
        }
    } catch(e){}

    // Jika berhasil load, kunci agar tidak didownload ulang
    if (successAWS || successAWOS) {
        isHistoryLoaded = true;
        console.log("History loaded completely. Switching to incremental update mode.");
    }
}

function renderData(type) {
    const list = (type === 'aws') ? historyAWS : historyAWOS;
    const idx = (type === 'aws') ? indexAWS : indexAWOS;
    
    // Safety check: jika list kosong, jangan error
    if (!list || list.length === 0) return;
    
    const data = list[idx];
    if (!data) return;

    let timeStr = data.timestamp;
    if (timeStr && timeStr.length > 16) timeStr = timeStr.substring(0, 16);
    
    const elTime = document.getElementById(type === 'aws' ? 'aws-time-main' : 'awos-time-main');
    if (elTime) elTime.innerText = timeStr;

    const subStatus = document.getElementById(type === 'aws' ? 'aws-status-sub' : 'awos-status-sub');
    if (subStatus) {
        if (idx === 0) {
            subStatus.innerText = "LATEST DATA";
            subStatus.className = "text-[0.7rem] font-bold text-green-600 uppercase tracking-wide leading-none mt-0.5";
        } else {
            subStatus.innerText = "HISTORY MODE";
            subStatus.className = "text-[0.7rem] font-bold text-red-500 uppercase tracking-wide leading-none mt-0.5";
        }
    }

    for (const [key, value] of Object.entries(data)) {
        const el = document.getElementById(key);
        if (el) {
            el.innerText = value;
            // Animasi highlight hanya jika mode Live (index 0)
            if (idx === 0) { 
                el.classList.remove('updated'); 
                void el.offsetWidth; // Trigger reflow
                el.classList.add('updated'); 
            }
        }
    }
    
    // Logika Tombol Next/Previous
    const btnNext = document.getElementById(type === 'aws' ? 'btn-next-aws' : 'btn-next-awos');
    if (btnNext) {
        if (idx > 0) btnNext.classList.remove('opacity-0', 'pointer-events-none');
        else btnNext.classList.add('opacity-0', 'pointer-events-none');
    }
}

function navigate(type, direction) {
    if (type === 'aws') manualModeAWS = true; else manualModeAWOS = true;
    const list = (type === 'aws') ? historyAWS : historyAWOS;
    const currentIndex = (type === 'aws') ? indexAWS : indexAWOS;
    let newIndex = currentIndex + direction;
    if (newIndex >= 0 && newIndex < list.length) {
        if (type === 'aws') indexAWS = newIndex; else indexAWOS = newIndex;
        renderData(type);
    }
}

function resetToLatest(type) {
    if (type === 'aws') { manualModeAWS = false; indexAWS = 0; }
    else { manualModeAWOS = false; indexAWOS = 0; }
    renderData(type);
}

function findDate(type) {
    const inputId = (type === 'aws') ? 'date-aws-input' : 'date-awos-input';
    const inputEl = document.getElementById(inputId);
    if(!inputEl) return;
    
    const inputVal = inputEl.value;
    if (!inputVal) return alert("Silakan klik area tanggal untuk memilih waktu.");

    if (type === 'aws') manualModeAWS = true; else manualModeAWOS = true;
    const list = (type === 'aws') ? historyAWS : historyAWOS;
    const targetTime = new Date(inputVal + ":00Z").getTime(); 
    
    if (list.length === 0) return alert("Data history kosong atau belum selesai dimuat.");
    let closestIndex = 0, minDiff = Infinity;
    list.forEach((item, idx) => {
        const itemTime = new Date(item.timestamp.replace(" ", "T") + "Z").getTime();
        const diff = Math.abs(targetTime - itemTime);
        if (diff < minDiff) { minDiff = diff; closestIndex = idx; }
    });

    if (type === 'aws') indexAWS = closestIndex; else indexAWOS = closestIndex;
    renderData(type);
}

function openTinjau(type) {
    const list = (type === 'aws') ? historyAWS : historyAWOS;
    const idx = (type === 'aws') ? indexAWS : indexAWOS;
    const data = list[idx];
    if (!data || !data.original_image) return alert("Gambar tidak ditemukan.");
    
    const modalImage = document.getElementById('modalImage');
    const modalTitle = document.getElementById('modalTitle');
    const imgPathDisplay = document.getElementById('imgPathDisplay');
    const imageModal = document.getElementById('imageModal');

    if (modalImage && modalTitle && imgPathDisplay && imageModal) {
        modalImage.src = data.original_image;
        modalTitle.innerText = "Capture: " + data.timestamp;
        imgPathDisplay.innerText = data.original_image;
        imageModal.classList.remove('hidden');
    }
}

// --- FITUR EXPORT CSV ---
let currentExportType = ''; 

function openExport(type) {
    currentExportType = type;
    const label = document.getElementById('exportTarget');
    if(label) label.innerText = type.toUpperCase();
    
    const now = new Date();
    const yesterday = new Date(now.getTime() - (24 * 60 * 60 * 1000));
    
    const formatUTC = (d) => {
        const pad = (n) => String(n).padStart(2, '0');
        return `${d.getUTCFullYear()}-${pad(d.getUTCMonth()+1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
    };

    document.getElementById('exp-start').value = formatUTC(yesterday);
    document.getElementById('exp-end').value = formatUTC(now);
    document.getElementById('exportModal').classList.remove('hidden');
}

function closeExportModal() {
    document.getElementById('exportModal').classList.add('hidden');
}

function doExport() {
    const startVal = document.getElementById('exp-start').value;
    const endVal = document.getElementById('exp-end').value;

    if (!startVal || !endVal) return alert("Harap isi Waktu Mulai dan Waktu Selesai!");
    
    const startStr = startVal.replace('T', ' ') + ':00';
    const endStr = endVal.replace('T', ' ') + ':00';
    window.location.href = `export.php?type=${currentExportType}&start=${encodeURIComponent(startStr)}&end=${encodeURIComponent(endStr)}`;
}

// --- SETUP AWAL (TANGGAL & MODAL) ---
function getUTCString(dateObj) {
    const pad = (n) => String(n).padStart(2, '0');
    return dateObj.getUTCFullYear() + '-' + pad(dateObj.getUTCMonth() + 1) + '-' + pad(dateObj.getUTCDate()) + 'T' + pad(dateObj.getUTCHours()) + ':' + pad(dateObj.getUTCMinutes());
}

document.addEventListener('DOMContentLoaded', () => {
    const now = new Date();
    const utcNowStr = getUTCString(now);
    const awsInput = document.getElementById('date-aws-input');
    const awosInput = document.getElementById('date-awos-input');
    if(awsInput) awsInput.value = utcNowStr;
    if(awosInput) awosInput.value = utcNowStr;

    const exportModal = document.getElementById('exportModal');
    const btnCloseX = document.getElementById('btnCloseModalX');
    const btnCancel = document.getElementById('btnCancelModal');
    
    if(btnCloseX) btnCloseX.addEventListener('click', closeExportModal);
    if(btnCancel) btnCancel.addEventListener('click', closeExportModal);
    if(exportModal) {
        exportModal.addEventListener('click', function(e) { if (e.target === this) closeExportModal(); });
    }

    document.querySelectorAll('.export-date-input').forEach(input => {
        input.addEventListener('click', (e) => e.stopPropagation());
    });
});

// Mulai Fetching setiap 3 detik
setInterval(fetchAllData, 3000);
fetchAllData();