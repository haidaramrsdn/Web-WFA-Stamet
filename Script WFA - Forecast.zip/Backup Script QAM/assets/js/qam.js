/**
 * Helper: Parse float aman
 */
function safeFloat(val) {
    if (!val) return null;
    const cleaned = String(val).replace(/[^\d.-]/g, '');
    const num = parseFloat(cleaned);
    return isNaN(num) ? null : num;
}

/**
 * LOGIKA WAKTU: Rounding Down (Floor) ke 30 Menit terdekat
 */
function getFlooredUTCTime() {
    const now = new Date();
    
    let h = now.getUTCHours();
    let m = now.getUTCMinutes();
    
    // Logika Floor 30 Menit
    if (m < 30) {
        m = 0;
    } else {
        m = 30;
    }

    const timeString = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    
    // Format Tanggal YYYY-MM-DD
    const y = now.getUTCFullYear();
    const mo = String(now.getUTCMonth() + 1).padStart(2, '0');
    const d = String(now.getUTCDate()).padStart(2, '0');
    const dateString = `${y}-${mo}-${d}`;

    return { date: dateString, time: timeString };
}

/**
 * Inisialisasi Tab QAM
 */
function initQAMTab() {
    // 1. Load Last State dari Server (User Input manual sebelumnya)
    fetch('json_data/qam_last_state.json?v=' + new Date().getTime())
        .then(response => response.json())
        .then(data => {
            const fields = ['observer', 'vis', 'wx', 'cloud', 'trend', 'supp'];
            fields.forEach(field => {
                if (data[field]) {
                    const el = document.getElementById('qam-' + field);
                    if(el) el.value = data[field];
                }
            });
        })
        .catch(err => console.log("Belum ada history server:", err));	

    // 2. Set Default Tanggal & Jam dengan Logika Floor (Kelipatan 30 menit)
    const calculated = getFlooredUTCTime();
    
    const elDate = document.getElementById('qam-date');
    const elTime = document.getElementById('qam-time');

    // Hanya set waktu jika input masih kosong (saat pertama load)
    if (elDate && !elDate.value) elDate.value = calculated.date;
    if (elTime && !elTime.value) elTime.value = calculated.time;

    // 3. Trigger Update Data Sensor (REVISI BUG RELOAD)
    // Langsung update (mungkin dapat data Latest dulu karena history belum load)
    updateQAMSensor();

    // Buat interval pengecekan:
    // Tunggu sampai `historyAWS` terisi banyak (artinya load background selesai)
    // Lalu paksa update sekali lagi agar data sesuai jam (bukan latest)
    let retryCount = 0;
    const checkHistoryLoaded = setInterval(() => {
        retryCount++;
        // Cek apakah historyAWS sudah didefinisikan di aws-awos.js dan isinya lebih dari 1
        if (typeof historyAWS !== 'undefined' && historyAWS.length > 5) {
            console.log("QAM: History loaded, correcting sensor data...");
            updateQAMSensor(); // Koreksi data
            clearInterval(checkHistoryLoaded); // Stop checking
        }
        
        // Stop mencoba setelah 10 detik agar tidak memakan memori
        if (retryCount > 10) clearInterval(checkHistoryLoaded);
    }, 1000); 
}

/**
 * Fungsi Utama: Mencari Data Sensor
 */
function updateQAMSensor() {
    const dateVal = document.getElementById('qam-date').value;
    const timeVal = document.getElementById('qam-time').value;
    
    if (!dateVal || !timeVal) return;

    // Target waktu (UTC) yang dipilih user
    const targetTs = new Date(`${dateVal}T${timeVal}:00Z`).getTime();

    // Fungsi pencari data terdekat
    function findClosestData(historyList) {
        if (!historyList || !Array.isArray(historyList) || historyList.length === 0) return null;
        
        let closest = null;
        let minDiff = Infinity; 
        
        historyList.forEach(item => {
            const itemTs = new Date(item.timestamp.replace(" ", "T") + "Z").getTime();
            const diff = Math.abs(targetTs - itemTs);
            
            if (diff < minDiff) { 
                minDiff = diff; 
                closest = item; 
            }
        });
        
        return closest;
    }

    // Ambil data dari variabel global di aws-awos.js
    const listAwos = (typeof historyAWOS !== 'undefined') ? historyAWOS : [];
    const listAws = (typeof historyAWS !== 'undefined') ? historyAWS : [];

    const dataAwos = findClosestData(listAwos);
    const dataAws = findClosestData(listAws);

    // -- ISI DATA AWOS --
    if (dataAwos) {
        document.getElementById('qam-wind-dir').value = dataAwos.awos_winddir || '';
        document.getElementById('qam-wind-spd').value = dataAwos.awos_winds || '';
        document.getElementById('qam-temp').value = dataAwos.awos_temp || '';
        document.getElementById('qam-dew').value = dataAwos.awos_dp || '';
    } else {
        // Kosongkan jika tidak ada data history sama sekali
        // (Opsional: bisa dikasih value '-' biar user tahu data belum siap)
    }

    // -- ISI DATA AWS --
    if (dataAws) {
        document.getElementById('qam-rh').value = dataAws.aws_rh || '';
        // Bersihkan data MSLP/QNH dari karakter non-angka
        document.getElementById('qam-qnh').value = dataAws.aws_mslp ? dataAws.aws_mslp.replace(/[^\d.-]/g, '') : '';
    }
}

/**
 * Tombol FETCH: Mengambil ulang data sesuai jam yang dipilih
 * (Menggantikan fungsi Reset)
 */
function refreshSensorData() {
    // Kita tidak mereset tanggal/jam ke 'now'.
    // Kita hanya memanggil ulang updateQAMSensor.
    // Ini akan menimpa editan manual user dengan data asli dari database/json.
    
    const btn = document.querySelector('button[onclick="refreshSensorData()"] i');
    if(btn) btn.classList.add('animate-spin'); // Efek putar icon sebentar
    
    updateQAMSensor();

    setTimeout(() => {
        if(btn) btn.classList.remove('animate-spin');
    }, 500);
}

/**
 * Cek Gambar Bukti
 */
function checkImageFromQAM(type) {
    const dateVal = document.getElementById('qam-date').value;
    const timeVal = document.getElementById('qam-time').value;
    if (!dateVal || !timeVal) return alert("Mohon isi Tanggal dan Jam (UTC) di form QAM terlebih dahulu.");

    const targetTs = new Date(`${dateVal}T${timeVal}:00Z`).getTime();
    
    const list = (type === 'aws') ? 
                 (typeof historyAWS !== 'undefined' ? historyAWS : []) : 
                 (typeof historyAWOS !== 'undefined' ? historyAWOS : []);

    if (list.length === 0) return alert("Data History belum dimuat atau kosong.");

    let closest = null, minDiff = Infinity;

    list.forEach(item => {
        const itemTs = new Date(item.timestamp.replace(" ", "T") + "Z").getTime();
        const diff = Math.abs(targetTs - itemTs);
        if (diff < minDiff) { minDiff = diff; closest = item; }
    });

    if (closest && closest.original_image) {
        document.getElementById('modalImage').src = closest.original_image;
        document.getElementById('modalTitle').innerText = `Capture ${type.toUpperCase()}: ${closest.timestamp}`;
        document.getElementById('imgPathDisplay').innerText = closest.original_image;
        document.getElementById('imageModal').classList.remove('hidden');
    } else {
        alert(`Gambar ${type.toUpperCase()} tidak ditemukan.`);
    }
}

/**
 * Generate Text Laporan
 */
function generateQAM() {
    const inputs = {};
    const ids = ['qam-observer', 'qam-date', 'qam-time', 'qam-vis', 'qam-wx', 'qam-cloud', 'qam-trend', 'qam-supp', 'qam-wind-dir', 'qam-wind-spd', 'qam-temp', 'qam-dew', 'qam-rh', 'qam-qnh'];
    let isEmpty = false;
    
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (!el.value.trim()) {
            el.classList.add('ring-2', 'ring-red-500'); 
            isEmpty = true;
        } else {
            el.classList.remove('ring-2', 'ring-red-500');
            inputs[id] = el.value.trim();
        }
    });

    if (isEmpty) return alert("Mohon lengkapi semua data.");

    const stateData = {};
    ['observer', 'vis', 'wx', 'cloud', 'trend', 'supp'].forEach(k => stateData[k] = inputs['qam-' + k]);
    fetch('save_qam_state.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(stateData) }).catch(e => console.error(e));

    const qnhVal = parseFloat(inputs['qam-qnh']);
    const qfeVal = qnhVal - 0.9; 
    const [y, m, d] = inputs['qam-date'].split('-');
    
    const finalMessage = `Weather Utarom Airport - ${d}/${m}/${y}\n\n👨🏽‍💻🛬 🛫 >>> 🌏☁\nReport = MET REPORT\nTime = ${inputs['qam-time'].replace(':', '.')} UTC\nWind = ${inputs['qam-wind-dir']}/${inputs['qam-wind-spd']} KT\nVis      =  ${inputs['qam-vis']} KM\nPresent Wx = ${inputs['qam-wx']}\nCloud  = ${inputs['qam-cloud']}\nTT    = ${inputs['qam-temp']}°C\nTD    = ${inputs['qam-dew']}°C\nRH    = ${inputs['qam-rh']} %\nQNH = ${qnhVal.toFixed(1)} mb - ${(qnhVal * 0.02953).toFixed(2)} inch\nQFE   = ${qfeVal.toFixed(1)} mb - ${(qfeVal * 0.02953).toFixed(2)} inch\nTREND = ${inputs['qam-trend']}\nSupp Info = ${inputs['qam-supp']}\n\nBy: Observer on Duty ${inputs['qam-observer']}`;

    document.getElementById('qam-result').value = finalMessage;
}

// --- LOGIKA KONTAK & DROPDOWN ---

// --- LOGIKA KONTAK & DEFAULT SETTINGS (UPDATED) ---

// Variabel global untuk menyimpan data sementara
let globalContacts = [];
let globalPrefs = {};

// Load kontak saat halaman dibuka
document.addEventListener('DOMContentLoaded', () => {
    loadContacts();
});

function loadContacts() {
    fetch('manage_contacts.php')
        .then(res => res.json())
        .then(data => {
            // Data sekarang formatnya: { contacts: [], prefs: {} }
            // Jika masih format lama (array), kita handle biar gak error
            const contacts = Array.isArray(data) ? data : (data.contacts || []);
            const prefs = data.prefs || {};

            globalContacts = contacts;
            globalPrefs = prefs;

            const dropdowns = ['qam-target-text', 'qam-target-media'];
            
            // 1. Render Dropdowns Utama
            dropdowns.forEach(id => {
                const el = document.getElementById(id);
                if(el) {
                    el.innerHTML = '';
                    // Option Kosong (Prompt)
                    const placeholder = document.createElement('option');
                    placeholder.text = "-- Pilih Kontak --";
                    placeholder.value = "";
                    el.appendChild(placeholder);

                    contacts.forEach(c => {
                        const opt = document.createElement('option');
                        opt.value = c.value + '|' + c.type; 
                        opt.innerText = c.name + (c.type === 'group' ? ' (Grup)' : '');
                        el.appendChild(opt);
                    });
                }
            });

            // 2. Set Default Value (Auto Select)
            if (prefs.default_text) {
                const elText = document.getElementById('qam-target-text');
                if(elText) elText.value = prefs.default_text;
            }
            if (prefs.default_media) {
                const elMedia = document.getElementById('qam-target-media');
                if(elMedia) elMedia.value = prefs.default_media;
            }

            // Update List di Modal (jika terbuka)
            renderModalList();
        })
        .catch(err => console.error("Gagal load kontak:", err));
}

// Render list di dalam Modal Manager
function renderModalList() {
    const listContainer = document.getElementById('contact-list-container');
    const prefText = document.getElementById('pref-default-text');
    const prefMedia = document.getElementById('pref-default-media');

    if (!listContainer) return;

    // Reset UI
    listContainer.innerHTML = '';
    if(prefText) {
        prefText.innerHTML = '<option value="">-- Tidak Ada Default --</option>';
        prefMedia.innerHTML = '<option value="">-- Tidak Ada Default --</option>';
    }

    globalContacts.forEach(c => {
        // 1. Render List Hapus
        const row = document.createElement('div');
        row.className = "flex justify-between items-center bg-white p-2 rounded border border-slate-200 text-xs";
        row.innerHTML = `
            <div>
                <div class="font-bold text-slate-700">${c.name}</div>
                <div class="font-mono text-slate-400 text-[10px] truncate max-w-[200px]">${c.value}</div>
            </div>
            <button onclick="deleteContact('${c.value}')" class="text-red-400 hover:text-red-600 px-2"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
        `;
        listContainer.appendChild(row);

        // 2. Populate Dropdown Default di Modal
        const valStr = c.value + '|' + c.type;
        const optText = new Option(c.name, valStr);
        const optMedia = new Option(c.name, valStr);
        
        if(prefText) prefText.add(optText);
        if(prefMedia) prefMedia.add(optMedia);
    });

    // Set value dropdown default di modal sesuai prefs saat ini
    if(prefText && globalPrefs.default_text) prefText.value = globalPrefs.default_text;
    if(prefMedia && globalPrefs.default_media) prefMedia.value = globalPrefs.default_media;

    if(typeof lucide !== 'undefined') lucide.createIcons();
}

// Fungsi Simpan Default Baru
function saveContactPrefs() {
    const defText = document.getElementById('pref-default-text').value;
    const defMedia = document.getElementById('pref-default-media').value;

    fetch('manage_contacts.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ 
            action: 'save_defaults', 
            default_text: defText,
            default_media: defMedia
        })
    }).then(() => {
        alert("Default berhasil disimpan!");
        loadContacts(); // Refresh agar dropdown utama langsung berubah
    });
}

function openContactManager() { 
    document.getElementById('contactModal').classList.remove('hidden'); 
    renderModalList(); // Refresh tampilan modal saat dibuka
}

function closeContactManager() { 
    document.getElementById('contactModal').classList.add('hidden'); 
}

function addContact() {
    const name = document.getElementById('new-contact-name').value;
    const type = document.getElementById('new-contact-type').value;
    const val = document.getElementById('new-contact-value').value;

    if(!name || !val) return alert("Nama dan Nilai (Link/HP) harus diisi!");

    fetch('manage_contacts.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ action: 'add', name, type, value: val })
    }).then(() => {
        // Clear input
        document.getElementById('new-contact-name').value = '';
        document.getElementById('new-contact-value').value = '';
        loadContacts();
    });
}

function deleteContact(val) {
    if(!confirm('Hapus kontak ini?')) return;
    fetch('manage_contacts.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ action: 'delete', value: val })
    }).then(() => loadContacts());
}

// --- LOGIKA MEDIA UPLOAD (PREVIEW) ---

function previewFile() {
    const input = document.getElementById('media-input');
    const preview = document.getElementById('file-preview-info');
    const placeholder = document.getElementById('upload-placeholder');
    const nameLabel = document.getElementById('preview-filename');
    const totalLabel = document.getElementById('preview-total');
    
    if (input.files && input.files.length > 0) {
        const count = input.files.length;
        
        // Tampilkan nama file pertama + info jumlah lain
        if (count === 1) {
            nameLabel.innerText = input.files[0].name;
            totalLabel.innerText = (input.files[0].size / 1024).toFixed(1) + " KB";
        } else {
            nameLabel.innerText = input.files[0].name;
            totalLabel.innerText = `+ ${count - 1} file lainnya (${count} total)`;
        }
        
        preview.classList.remove('hidden');
        preview.classList.add('flex');
        placeholder.classList.add('opacity-0'); 
        if(typeof lucide !== 'undefined') lucide.createIcons();
    }
}

function resetFile(e) {
    if(e) e.stopPropagation();
    const input = document.getElementById('media-input');
    input.value = ''; // Reset
    
    document.getElementById('file-preview-info').classList.add('hidden');
    document.getElementById('file-preview-info').classList.remove('flex');
    document.getElementById('upload-placeholder').classList.remove('opacity-0');
}


// --- FUNGSI UPDATE SEND TEXT (MODIFIED) ---
// Timpa fungsi sendAndCopyQAM yang lama agar menggunakan target dari dropdown
async function sendAndCopyQAM() {
    const textArea = document.getElementById("qam-result");
    const targetSelect = document.getElementById("qam-target-text");
    const messageVal = textArea.value;
    
    if (!messageVal) return alert("Generate pesan terlebih dahulu!");
    
    const [targetValue, targetType] = targetSelect.value.split('|');

    const btn = document.getElementById('btn-send-qam');
    const originalText = btn.innerHTML;
    btn.innerHTML = 'Sending...';
    btn.disabled = true;

    try {
        const formData = new FormData();
        formData.append('message', messageVal);
        formData.append('target_value', targetValue);
        formData.append('target_type', targetType);
        formData.append('type', 'text'); // Penanda bahwa ini pesan teks

        // Note: Kita akan buat save_qam_queue.php di Tahap 2, 
        // untuk sekarang ini akan error 404 tapi UI sudah siap.
        const response = await fetch('save_qam_queue.php', { method: 'POST', body: formData });
        const result = await response.json();

        if (result.status === 'success') {
            btn.innerHTML = 'Sent!';
            document.getElementById('copy-status').innerText = "Terkirim ke Antrian!";
            document.getElementById('copy-status').style.opacity = '1';
        } else {
            alert("GAGAL: " + result.msg);
        }
    } catch (error) {
        // alert("Backend belum siap (Lanjut ke Tahap 2)"); 
        console.log(error);
    } finally {
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }, 2000);
    }
}

// Placeholder fungsi upload (akan diisi di Tahap 2)
// --- UPDATE FUNGSI UPLOAD MEDIA ---

async function uploadMedia() {
    const fileInput = document.getElementById('media-input');
    const targetSelect = document.getElementById('qam-target-media');
    const captionBox = document.getElementById('media-caption');
    const messageVal = captionBox.value.trim();
    
    const btn = document.getElementById('btn-upload-media');
    const statusEl = document.getElementById('upload-status');

    // Cek File
    const files = fileInput.files;
    const hasFile = files && files.length > 0;

    if (!hasFile && !messageVal) return alert("Isi pesan atau lampirkan file!");
    if (!targetSelect.value) return alert("Pilih target pengiriman!");

    const [targetValue, targetType] = targetSelect.value.split('|');

    // UI Loading
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i data-lucide="loader-2" class="w-5 h-5 animate-spin"></i> Memproses...';
    btn.disabled = true;
    statusEl.innerText = '';
    if(typeof lucide !== 'undefined') lucide.createIcons();

    try {
        const formData = new FormData();
        formData.append('target_value', targetValue);
        formData.append('target_type', targetType);
        formData.append('message', messageVal); // Caption hanya untuk file pertama (biasanya) atau teks terpisah

        // Logika Pengiriman:
        // Jika ada BANYAK file, kita kirim semuanya dalam form data array
        if (hasFile) {
            formData.append('type', 'media');
            for (let i = 0; i < files.length; i++) {
                formData.append('files[]', files[i]); // Perhatikan 'files[]' pakai kurung siku
            }
        } else {
            formData.append('type', 'text');
        }

        const response = await fetch('save_qam_queue.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();

        if (result.status === 'success') {
            statusEl.className = "text-center text-xs font-bold h-4 text-green-600";
            statusEl.innerText = `Sukses! ${result.queue_added} antrian dibuat.`;
            
            resetFile(null); 
            captionBox.value = ''; 
        } else {
            throw new Error(result.msg || "Server Error");
        }
    } catch (error) {
        statusEl.className = "text-center text-xs font-bold h-4 text-red-600";
        statusEl.innerText = "Gagal: " + error.message;
    } finally {
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.disabled = false;
            if(typeof lucide !== 'undefined') lucide.createIcons();
        }, 2000);
    }
}

