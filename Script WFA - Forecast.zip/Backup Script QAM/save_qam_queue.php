<?php
// save_qam_queue.php (SUPPORT MULTIPLE FILES)
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
ini_set('display_errors', 0);
error_reporting(E_ALL);

$response = array();

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new Exception('Request harus POST.');
    
    // Validasi Ukuran File Global
    if (empty($_POST) && empty($_FILES) && isset($_SERVER['CONTENT_LENGTH']) && $_SERVER['CONTENT_LENGTH'] > 0) {
        throw new Exception("Total ukuran file terlalu besar! Batas server: " . ini_get('post_max_size'));
    }

    // --- KONFIGURASI ---
    $PHYSICAL_DIR = __DIR__ . '/file_queue/'; 
    $WINDOWS_PATH_PREFIX = 'F:\\file_queue\\'; 
    $QUEUE_DIR = __DIR__ . '/json_queue/';

    if (!is_dir($QUEUE_DIR)) mkdir($QUEUE_DIR, 0777, true);
    if (!is_dir($PHYSICAL_DIR)) mkdir($PHYSICAL_DIR, 0777, true);

    // Ambil Data Dasar
    $type = $_POST['type'] ?? 'text';
    $targetValue = $_POST['target_value'] ?? '';
    $message = $_POST['message'] ?? '';
    $targetType = $_POST['target_type'] ?? 'group';

    if (empty($targetValue)) throw new Exception('Target belum dipilih.');

    $jobsCreated = 0;

    // --- SKENARIO 1: MULTIPLE FILES ---
    if ($type === 'media' && isset($_FILES['files'])) {
        $fileList = $_FILES['files'];
        // Re-structure array $_FILES agar mudah di-loop
        $count = count($fileList['name']);
        
        for ($i = 0; $i < $count; $i++) {
            if ($fileList['error'][$i] !== UPLOAD_ERR_OK) continue; // Skip error

            // 1. Simpan File Fisik
            $tmpName = $fileList['tmp_name'][$i];
            $origName = $fileList['name'][$i];
            
            $cleanName = preg_replace("/[^a-zA-Z0-9\.]/", "_", $origName);
            $newFileName = time() . "_{$i}_" . $cleanName; // Tambah index $i agar unik jika nama sama
            
            if (move_uploaded_file($tmpName, $PHYSICAL_DIR . $newFileName)) {
                $finalFilePath = $WINDOWS_PATH_PREFIX . $newFileName;
                
                // 2. Buat Tiket Job
                // PENTING: Caption ($message) hanya ditempel ke FILE PERTAMA
                // File kedua dst dikirim tanpa caption (atau user akan spam caption)
                $msgForThisFile = ($i === 0) ? $message : ""; 

                $jobId = uniqid() . "_$i";
                $jobData = [
                    'id' => $jobId,
                    'timestamp' => date('Y-m-d H:i:s'),
                    'type' => 'media',
                    'target_type' => $targetType,
                    'target_value' => $targetValue,
                    'message' => $msgForThisFile, 
                    'attachment' => $finalFilePath,
                    'status' => 'pending'
                ];

                // Simpan JSON Tiket
                // Tambahkan sleep microsecond agar nama file json urut sempurna
                usleep(50000); 
                $filename = 'job_' . microtime(true) . '_' . $jobId . '.json';
                file_put_contents($QUEUE_DIR . $filename, json_encode($jobData, JSON_PRETTY_PRINT));
                
                $jobsCreated++;
            }
        }
        
        if ($jobsCreated === 0) throw new Exception("Gagal upload semua file (Cek permission/ukuran).");
    } 
    
    // --- SKENARIO 2: TEXT ONLY (ATAU JIKA FILE GAGAL TAPI ADA PESAN) ---
    else {
        // Jika type text, atau type media tapi tidak ada file terkirim (tapi ada pesan)
        if (!empty($message)) {
            $jobId = uniqid();
            $jobData = [
                'id' => $jobId,
                'timestamp' => date('Y-m-d H:i:s'),
                'type' => 'text',
                'target_type' => $targetType,
                'target_value' => $targetValue,
                'message' => $message,
                'attachment' => null,
                'status' => 'pending'
            ];
            
            $filename = 'job_' . microtime(true) . '_' . $jobId . '.json';
            file_put_contents($QUEUE_DIR . $filename, json_encode($jobData, JSON_PRETTY_PRINT));
            $jobsCreated++;
        } else {
            throw new Exception("Tidak ada file dan tidak ada pesan yang dikirim.");
        }
    }

    $response['status'] = 'success';
    $response['msg'] = 'Jobs added';
    $response['queue_added'] = $jobsCreated;

} catch (Exception $e) {
    http_response_code(500);
    $response['status'] = 'error';
    $response['msg'] = $e->getMessage();
}

echo json_encode($response);
?>