<?php
// manage_contacts.php (UPDATED WITH DEFAULTS)
header("Content-Type: application/json");

// Dua file database json
$fileContacts = __DIR__ . '/json_data/contacts.json';
$filePrefs = __DIR__ . '/json_data/contact_prefs.json';

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

// Helper Functions
function getJson($f) { return file_exists($f) ? json_decode(file_get_contents($f), true) : []; }
function saveJson($f, $d) { file_put_contents($f, json_encode($d, JSON_PRETTY_PRINT)); }

// --- GET: Ambil Kontak DAN Default Prefs ---
if ($method === 'GET') {
    echo json_encode([
        'contacts' => getJson($fileContacts),
        'prefs' => getJson($filePrefs)
    ]);
    exit;
}

// --- POST: Tambah/Hapus/Simpan Default ---
if ($method === 'POST') {
    // A. Manage Kontak (Tambah/Hapus)
    if ($action === 'add' || $action === 'delete') {
        $contacts = getJson($fileContacts);
        if(!is_array($contacts)) $contacts = []; // Safety check
        
        if ($action === 'add') {
            $contacts[] = [
                'name' => $input['name'],
                'type' => $input['type'], 
                'value' => $input['value']
            ];
        } elseif ($action === 'delete') {
            $valToDelete = $input['value'];
            $contacts = array_filter($contacts, function($item) use ($valToDelete) {
                return $item['value'] !== $valToDelete;
            });
            $contacts = array_values($contacts); // Reindex
        }
        saveJson($fileContacts, $contacts);
        echo json_encode(['status' => 'success']);
    }
    
    // B. Simpan Default (Fitur Baru)
    if ($action === 'save_defaults') {
        $prefs = [
            'default_text' => $input['default_text'] ?? '',
            'default_media' => $input['default_media'] ?? ''
        ];
        saveJson($filePrefs, $prefs);
        echo json_encode(['status' => 'success']);
    }
    exit;
}
?>