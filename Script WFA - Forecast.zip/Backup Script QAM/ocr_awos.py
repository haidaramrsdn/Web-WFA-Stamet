import cv2
import numpy as np
import pytesseract
import os
import re

# Pastikan path tesseract sudah benar sesuai environment Anda
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

CONFIG_NUMERIC = r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789.-/'
CONFIG_WIND = r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789.-calmVRBv/'

# --- CONFIG OFFSET ---
roi_configs = [
    {"tpl": "awos_anchor_AirTemp.png",      "ox": 5,   "oy": 23,  "w": 80,  "h": 40, "label": "awos_temp", "type": "numeric"},
    {"tpl": "awos_anchor_RH.png",           "ox": -20, "oy": 23,  "w": 70,  "h": 40, "label": "awos_rh", "type": "numeric"},
    {"tpl": "awos_anchor_DewPoint.png",     "ox": 0,   "oy": 23,  "w": 70,  "h": 40, "label": "awos_dp", "type": "numeric"},
    {"tpl": "awos_anchor_WindDirection.png","ox": -10, "oy": -48, "w": 120, "h": 45, "label": "awos_winddir", "type": "wind"},
    {"tpl": "awos_anchor_WindSpeed.png",    "ox": -5,  "oy": 20,  "w": 90,  "h": 35, "label": "awos_winds", "type": "wind"},
    {"tpl": "awos_anchor_2Min.png",         "ox": 68,  "oy": -4,  "w": 57,  "h": 43, "label": "awos_2min_winds", "type": "numeric"},
    {"tpl": "awos_anchor_2Min.png",         "ox": 152, "oy": -6,  "w": 78,  "h": 43, "label": "awos_2min_winddir", "type": "numeric"},
    {"tpl": "awos_anchor_2Min.png",         "ox": 248, "oy": -6,  "w": 50,  "h": 43, "label": "awos_2min_windsmin", "type": "numeric"},
    {"tpl": "awos_anchor_2Min.png",         "ox": 323, "oy": -6,  "w": 50,  "h": 43, "label": "awos_2min_windsmax", "type": "numeric"},
    {"tpl": "awos_anchor_Cross.png",        "ox": 0,   "oy": 20,  "w": 55,  "h": 43, "label": "awos_2min_windscross", "type": "wind"},
    {"tpl": "awos_anchor_HeadTail.png",     "ox": 13,  "oy": 20,  "w": 55,  "h": 43, "label": "awos_2min_windsheadtail", "type": "numeric"},
    {"tpl": "awos_anchor_SolarRadiation.png","ox": 84,  "oy": 25,  "w": 71,  "h": 38, "label": "awos_radiation", "type": "numeric"},
    {"tpl": "awos_anchor_Precipitation.png", "ox": 64,  "oy": 52,  "w": 53,  "h": 36, "label": "awos_precipitation", "type": "numeric"},
    {"tpl": "awos_anchor_QFE.png",          "ox": -24, "oy": 27,  "w": 97,  "h": 43, "label": "awos_qfe", "type": "numeric"},
    {"tpl": "awos_anchor_QNH.png",          "ox": -24, "oy": 28,  "w": 97,  "h": 43, "label": "awos_qnh", "type": "numeric"},
    {"tpl": "awos_anchor_DensityAltitude.png","ox": 150, "oy": -15, "w": 151, "h": 54, "label": "awos_densalt", "type": "numeric"},
    {"tpl": "awos_anchor_VariableWinds.png", "ox": 0,   "oy": 20,  "w": 135, "h": 44, "label": "awos_varwinds", "type": "wind"},
    {"tpl": "awos_anchor_Gust.png",         "ox": -22, "oy": 20,  "w": 90,  "h": 44, "label": "awos_gust", "type": "wind"},
]

def clean_standard_value(text):
    if text is None: return None
    text = text.strip()
    if len(text) == 0 or '/' in text: return None
    if not re.search(r'\d', text): return None
    return text

def clean_wind_value(text):
    if text is None: return None
    text = text.strip()
    text_lower = text.lower()
    
    if '/' in text or len(text) == 0: return None
    if "calm" in text_lower: return "0"
    if "vrb" in text_lower: return "VRB"
    if "v" in text_lower and any(char.isdigit() for char in text): return text.upper()
    
    digits_only = re.sub(r'\D', '', text)
    if digits_only:
        return digits_only[:3] if len(digits_only) > 3 else digits_only

    if not re.search(r'\d', text): return None
    return text

def pre_process_universal(img_rgb_crop):
    """
    Fungsi universal untuk mengekstrak teks berwarna (merah, kuning, hijau, putih)
    di atas background gelap.
    """
    # Ambil nilai intensitas maksimum dari RGB
    gray = np.max(img_rgb_crop, axis=2)
    
    # Threshold statis karena kontras sudah pasti tinggi
    _, thresh = cv2.threshold(gray, 50, 255, cv2.THRESH_BINARY)
    
    # Invert agar teks hitam di atas background putih
    return cv2.bitwise_not(thresh)
 
def pre_process_dial(img_rgb_crop):
    """
    Khusus untuk area lingkaran angin.
    Mengambil teks Merah, Kuning, Hijau, tapi membuang Biru (grid) dan Putih (jarum).
    """
    hsv = cv2.cvtColor(img_rgb_crop, cv2.COLOR_BGR2HSV)
    
    # Range 1: Merah bawah, Kuning, hingga Hijau (Hue: 0 - 90)
    # Saturation > 100 membuang warna putih/abu-abu dari jarum indikator
    lower1 = np.array([0, 100, 100])
    upper1 = np.array([90, 255, 255])
    mask1 = cv2.inRange(hsv, lower1, upper1)
    
    # Range 2: Merah atas (Hue: 160 - 180)
    lower2 = np.array([160, 100, 100])
    upper2 = np.array([180, 255, 255])
    mask2 = cv2.inRange(hsv, lower2, upper2)
    
    # Gabungkan mask
    mask = cv2.bitwise_or(mask1, mask2)
    
    # Bersihkan noise kecil
    kernel = np.ones((2,2), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    
    return cv2.bitwise_not(mask)

def extract_awos_data_from_image(img_rgb, templates_path):
    data = {}
    if img_rgb is None: return None
    
    # img_gray di sini hanya digunakan untuk pencocokan template (cv2.matchTemplate)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

    for config in roi_configs:
        tpl_path = os.path.join(templates_path, config['tpl'])
        if not os.path.exists(tpl_path):
            data[config['label']] = None
            continue
        
        template = cv2.imread(tpl_path, 0)
        res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)

        final_val = None
        if max_val >= 0.8:
            ax, ay = max_loc
            vx, vy, vw, vh = ax + config['ox'], ay + config['oy'], config['w'], config['h']

            roi_rgb = img_rgb[vy:vy+vh, vx:vx+vw]
            
            # CEK LOKASI: Jika ini teks di dalam lingkaran kompas
            if config['label'] in ['awos_winddir', 'awos_winds']:
                roi_proc = pre_process_dial(roi_rgb)
            else:
                roi_proc = pre_process_universal(roi_rgb)

            # Eksekusi Tesseract
            if config.get('type') == 'wind':
                raw_text = pytesseract.image_to_string(roi_proc, config=CONFIG_WIND)
                final_val = clean_wind_value(raw_text)
            else:
                raw_text = pytesseract.image_to_string(roi_proc, config=CONFIG_NUMERIC)
                final_val = clean_standard_value(raw_text)

        data[config['label']] = final_val

    return data

def extract_awos_data(image_path, templates_path):
    img = cv2.imread(image_path)
    return extract_awos_data_from_image(img, templates_path)