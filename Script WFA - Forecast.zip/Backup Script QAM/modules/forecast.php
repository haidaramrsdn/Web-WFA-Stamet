<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600&family=JetBrains+Mono:wght@400;500&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

<style>
    /* Styling Umum Overlay */
    .overlay-input {
        position: absolute;
        transform: translate(-50%, -50%);
        z-index: 10;
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255,255,255,0.1);
        text-align: center;
        font-size: 12px;
        font-weight: bold;
        color: #000;
        cursor: pointer;
        transition: background-color 0.2s, border 0.2s;
        border-radius: 4px;
    }
    .overlay-input:hover, .overlay-input:focus {
        background-color: rgba(255, 255, 255, 1);
        border: 2px solid #2563eb; 
        z-index: 20;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        color: #000 !important;
    }
    select.overlay-input { appearance: none; -webkit-appearance: none; text-align-last: center; }

    /* Wrapper Canvas */
    .canvas-wrapper {
        position: relative; 
        min-width: 1270px; min-height: 1270px; 
        width: 1270px; height: 1270px; 
        box-shadow: 0 10px 30px -10px rgba(0,0,0,0.3);
        background-color: white;
    }

    /* Scrollbar */
    .custom-scroll::-webkit-scrollbar { width: 14px; height: 14px; }
    .custom-scroll::-webkit-scrollbar-track { background: #f1f5f9; }
    .custom-scroll::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 7px; border: 3px solid #f1f5f9; }
    
    /* INPUT KHUSUS PASUT (TEXT PUTIH MUTLAK) */
    .pasut-input {
        font-family: 'Roboto', sans-serif;
        font-size: 14px;
        background-color: rgba(0, 0, 0, 0.3) !important; 
        border: 1px solid rgba(255, 255, 255, 0.4) !important;
        color: #ffffff !important; 
        text-shadow: 0 1px 2px rgba(0,0,0,0.8);
    }
    .pasut-input::placeholder { color: rgba(255, 255, 255, 0.5) !important; }
    .pasut-input:focus { 
        background-color: rgba(0, 0, 0, 0.8) !important; 
        border-color: #60a5fa !important; 
        color: #ffffff !important; 
        z-index: 50;
    }
    .pasut-input::-webkit-outer-spin-button,
    .pasut-input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
</style>

<section id="forecast-container" class="hidden max-w-7xl mx-auto mb-12 space-y-12">
    
    <div class="bg-white rounded-xl shadow-xl border-t-[6px] border-blue-600 overflow-hidden ring-1 ring-slate-900/5">
        <div class="px-6 py-4 border-b border-slate-200 bg-slate-50/80 backdrop-blur flex justify-between items-center">
            <h2 class="text-2xl font-black text-slate-700 flex items-center gap-3 tracking-tight">
                <div class="p-2 bg-blue-100 text-blue-600 rounded-lg"><i data-lucide="cloud-sun" class="w-6 h-6"></i></div>
                WEATHER FORECAST
            </h2>
            <div class="text-xs font-bold font-mono tracking-wider bg-blue-100 text-blue-700 px-3 py-1.5 rounded-full border border-blue-200">
                INFOGRAFIS MEDSOS
            </div>
        </div>

        <div class="p-6 lg:p-8 flex flex-col gap-6">
            <div class="bg-slate-50 p-5 rounded-xl border border-slate-200 flex flex-col md:flex-row items-end justify-between gap-4">
                
                <div class="flex flex-col md:flex-row gap-4 w-full md:w-auto">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Mulai (Waktu Lokal)</label>
                        <div class="relative">
                            <i data-lucide="calendar-clock" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none"></i>
                            <input type="datetime-local" id="date_start" onchange="generateHeader()" 
                                class="pl-10 pr-4 h-11 w-full md:w-72 border border-slate-300 rounded-lg text-base font-mono text-slate-700 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none shadow-sm bg-white cursor-pointer transition-all">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Selesai (Waktu Lokal)</label>
                        <div class="relative">
                            <i data-lucide="calendar-check" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none"></i>
                            <input type="datetime-local" id="date_end" onchange="generateHeader()" 
                                class="pl-10 pr-4 h-11 w-full md:w-72 border border-slate-300 rounded-lg text-base font-mono text-slate-700 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none shadow-sm bg-white cursor-pointer transition-all">
                        </div>
                    </div>
                    <input type="hidden" id="fc_date">
                </div>

                <div class="flex flex-col items-end gap-1 w-full md:w-auto">
                     <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Export</div>
                     <button onclick="downloadAll()" class="w-full md:w-auto h-11 bg-green-600 hover:bg-green-700 text-white px-6 rounded-lg font-bold shadow-lg shadow-green-600/20 flex items-center justify-center gap-2 transition-all active:scale-95">
                        <i data-lucide="download-cloud" class="w-5 h-5"></i> Download Paket JPG
                    </button>
                </div>
            </div>

            <div class="w-full h-[75vh] overflow-auto custom-scroll bg-slate-200 p-4 border rounded-xl border-slate-300 relative shadow-inner">
                <div class="canvas-wrapper mx-auto">
                    <canvas id="forecastCanvas" width="1270" height="1270" class="absolute top-0 left-0 z-0"></canvas>
                    
                    <?php 
                    $ROW_START_Y = 372; $ROW_STEP_Y = 83;
                    $COL_START_X = 225; $COL_STEP_X = 82;
                    $POS_TEMP_X = 975; $POS_RH_X = 1076; $POS_WIND_X = 1178;
                    $districts = ['Buruway', 'Kaimana', 'Kambrau', 'Teluk Arguni Atas', 'Teluk Arguni Bawah', 'Teluk Etna', 'Yamor'];
                    $hours = ['09', '12', '15', '18', '21', '00', '03', '06', '09_besok'];
                    $weather_opts = ['cerah'=>'Cerah', 'cerah_berawan'=>'Cerah Berawan', 'berawan'=>'Berawan', 'berawan_tebal'=>'Berawan Tebal', 'udara_kabur'=>'Udara Kabur', 'kabut'=>'Kabut', 'hujan_ringan'=>'Hujan Ringan', 'hujan_sedang'=>'Hujan Sedang', 'hujan_lebat'=>'Hujan Lebat', 'hujan_petir'=>'Hujan Petir', 'petir'=>'Petir'];
                    $wind_opts = ['utara'=>'Utara', 'timur_laut'=>'Timur Laut', 'timur'=>'Timur', 'tenggara'=>'Tenggara', 'selatan'=>'Selatan', 'barat_daya'=>'Barat Daya', 'barat'=>'Barat', 'barat_laut'=>'Barat Laut'];
                    
                    foreach($districts as $dIdx => $dist):
                        $top = $ROW_START_Y + ($dIdx * $ROW_STEP_Y);
                        foreach($hours as $hIdx => $h):
                            $left = $COL_START_X + ($hIdx * $COL_STEP_X);
                    ?>
                        <select class="overlay-input fc-weather" data-district="<?= $dIdx ?>" data-col="<?= $h ?>" style="top: <?= $top ?>px; left: <?= $left ?>px; width: 80px; height: 80px; opacity: 0.05;">
                            <?php foreach($weather_opts as $k=>$v): echo "<option value='$k'>$v</option>"; endforeach; ?>
                        </select>
                    <?php endforeach; ?>
                        <input type="number" class="overlay-input fc-temp-min" data-district="<?= $dIdx ?>" value="20" style="top: <?= $top ?>px; left: <?= $POS_TEMP_X - 25 ?>px; width: 40px; height: 30px;">
                        <input type="number" class="overlay-input fc-temp-max" data-district="<?= $dIdx ?>" value="30" style="top: <?= $top ?>px; left: <?= $POS_TEMP_X + 25 ?>px; width: 40px; height: 30px;">
                        <input type="number" class="overlay-input fc-rh-min" data-district="<?= $dIdx ?>" value="60" style="top: <?= $top ?>px; left: <?= $POS_RH_X - 25 ?>px; width: 40px; height: 30px;">
                        <input type="number" class="overlay-input fc-rh-max" data-district="<?= $dIdx ?>" value="80" style="top: <?= $top ?>px; left: <?= $POS_RH_X + 25 ?>px; width: 40px; height: 30px;">
                        <select class="overlay-input fc-wind-dir" data-district="<?= $dIdx ?>" style="top: <?= $top - 25 ?>px; left: <?= $POS_WIND_X ?>px; width: 50px; height: 40px; opacity: 0.1;">
                            <?php foreach($wind_opts as $k=>$v): echo "<option value='$k'>$v</option>"; endforeach; ?>
                        </select>
                        <input type="text" class="overlay-input fc-wind-speed" data-district="<?= $dIdx ?>" value="0" style="top: <?= $top + 25 ?>px; left: <?= $POS_WIND_X ?>px; width: 50px; height: 25px;" placeholder="Km/H">
                    <?php endforeach; ?>
                    <textarea id="fc_warning" class="overlay-input" 
                              style="top: 1150px; left: 635px; width: 1050px; height: 80px; text-align: left; padding: 10px; font-size: 26px; font-family: 'Roboto', sans-serif;" 
                              placeholder="Ketik Peringatan Dini disini (Klik untuk mengedit)...">NIL</textarea>
                </div>
            </div>
            
            <div class="text-center text-xs text-slate-400 italic">
                Tips: Hover pada kotak kuning di bawah gambar untuk mengedit Peringatan Dini.
            </div>

        </div>
    </div>

    <div class="bg-white rounded-xl shadow-xl border-t-[6px] border-indigo-600 overflow-hidden ring-1 ring-slate-900/5">
        <div class="px-6 py-4 border-b border-slate-200 bg-slate-50/80 backdrop-blur flex justify-between items-center">
            <h2 class="text-2xl font-black text-slate-700 flex items-center gap-3 tracking-tight">
                <div class="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><i data-lucide="waves" class="w-6 h-6"></i></div>
                TIDE FORECAST (PASANG SURUT)
            </h2>
        </div>

        <div class="p-6 lg:p-8 flex flex-col gap-6">
            <div class="bg-indigo-50 p-5 rounded-xl border border-indigo-100 flex flex-col md:flex-row items-end gap-6">
                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Mode Template</label>
                    <div class="flex bg-white rounded-lg p-1 border border-slate-300 shadow-sm">
                        <button onclick="switchTideMode('1day')" id="btn-tide-1day" class="px-4 py-2 rounded-md text-sm font-bold transition-all bg-indigo-600 text-white shadow">1 Hari</button>
                        <button onclick="switchTideMode('3day')" id="btn-tide-3day" class="px-4 py-2 rounded-md text-sm font-bold transition-all text-slate-500 hover:bg-indigo-50">3 Hari</button>
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Tanggal Awal (Waktu Lokal)</label>
                    <div class="relative">
                        <i data-lucide="calendar" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-400 pointer-events-none"></i>
                        <input type="date" id="tide_date_start" onchange="drawTide()" class="pl-10 pr-3 h-11 border border-slate-300 rounded-lg text-base font-mono text-slate-700 focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none shadow-sm bg-white w-48 cursor-pointer">
                    </div>
                </div>
                <div class="ml-auto">
                     <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 text-right">Actions</div>
                     <button onclick="downloadTide()" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-lg font-bold shadow-lg shadow-indigo-600/20 flex items-center gap-2 h-11 transition-all active:scale-95">
                        <i data-lucide="image-down" class="w-5 h-5"></i> Download Grafik
                    </button>
                </div>
            </div>

            <div class="w-full h-[75vh] overflow-auto custom-scroll bg-slate-200 p-4 border rounded-xl border-slate-300 relative shadow-inner">
                <div class="canvas-wrapper mx-auto">
                    <canvas id="tideCanvas" width="1270" height="1270" class="absolute top-0 left-0 z-0"></canvas>
                    
                    <div id="tide-inputs-container">
                        <?php 
                        $Y_START = 357; $Y_END = 1081; $TOTAL_STEPS = 23;
                        $STEP_SIZE = ($Y_END - $Y_START) / $TOTAL_STEPS;
                        $X_1DAY_COL = 209; $X_3DAY_COL1 = 151; $X_3DAY_COL2 = 205; $X_3DAY_COL3 = 260;
                        
                        for ($i = 0; $i <= 23; $i++) {
                            $top = $Y_START + ($i * $STEP_SIZE);
                        ?>
                            <input type="number" step="0.1" class="overlay-input pasut-input tide-input-1day" 
                                   data-hour="<?= $i ?>" style="top: <?= $top ?>px; left: <?= $X_1DAY_COL ?>px; width: 45px; height: 26px;" placeholder="-">

                            <input type="number" step="0.1" class="overlay-input pasut-input tide-input-3day-col1 hidden" 
                                   data-hour="<?= $i ?>" data-day="0" style="top: <?= $top ?>px; left: <?= $X_3DAY_COL1 ?>px; width: 45px; height: 26px;" placeholder="-">

                            <input type="number" step="0.1" class="overlay-input pasut-input tide-input-3day-col2 hidden" 
                                   data-hour="<?= $i ?>" data-day="1" style="top: <?= $top ?>px; left: <?= $X_3DAY_COL2 ?>px; width: 45px; height: 26px;" placeholder="-">

                            <input type="number" step="0.1" class="overlay-input pasut-input tide-input-3day-col3 hidden" 
                                   data-hour="<?= $i ?>" data-day="2" style="top: <?= $top ?>px; left: <?= $X_3DAY_COL3 ?>px; width: 45px; height: 26px;" placeholder="-">
                        <?php } ?>
                    </div>
                </div>
            </div>
             <div class="text-center text-xs text-slate-400 italic">
                Tips: Masukkan data ketinggian (meter) pada kolom tabel. Grafik akan tergambar otomatis.
            </div>
        </div>
    </div>
</section>