<section class="bg-white rounded-xl shadow-md border-l-[8px] border-bmkg flex flex-col md:flex-row overflow-hidden">
            <div class="p-6 md:w-80 flex flex-col gap-5 border-b md:border-b-0 md:border-r border-slate-100 bg-slate-50 relative">
                <h2 class="text-4xl font-black text-bmkg tracking-tight">AWS</h2>
                
                <div class="flex gap-2 h-14 mt-2">
                    <div class="relative group flex-1 h-full bg-white border border-slate-300 rounded-lg shadow-sm hover:border-bmkg transition-colors overflow-hidden">
                        <input type="datetime-local" id="date-aws-input" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20">
                        
                        <div class="absolute inset-0 flex flex-col justify-center px-3 pointer-events-none z-10">
                            <div id="aws-time-main" class="text-base font-mono font-bold text-slate-700 truncate">Waiting...</div>
                            <div id="aws-status-sub" class="text-[0.7rem] font-bold text-green-600 uppercase tracking-wide leading-none mt-0.5 opacity-0">Latest Data</div>
                        </div>
                    </div>
                    <button onclick="findDate('aws')" class="bg-bmkg hover:bg-blue-700 text-white font-bold px-4 rounded-lg shadow-sm text-sm transition-colors active:scale-95 h-full">
                        Set
                    </button>
                </div>

                <div class="flex gap-2 mt-1">
                    <button onclick="resetToLatest('aws')" class="flex-1 py-2 text-sm font-bold border border-slate-300 bg-white rounded-lg hover:bg-slate-100 transition-colors text-slate-700 shadow-sm">Live</button>
                    <button onclick="openTinjau('aws')" class="flex-1 py-2 text-sm font-bold border border-slate-300 bg-white rounded-lg hover:bg-slate-100 transition-colors text-slate-700 shadow-sm flex justify-center items-center gap-2">
                        <i data-lucide="eye" class="w-4 h-4"></i> Check
                    </button>
                </div>
                <button onclick="openExport('aws')" class="w-full mt-2 py-2 text-sm font-bold border border-green-600 text-green-700 bg-green-50 rounded-lg hover:bg-green-600 hover:text-white transition-all shadow-sm flex justify-center items-center gap-2 group">
                    <i data-lucide="file-down" class="w-4 h-4 group-hover:animate-bounce"></i> Extract Data CSV
                </button>

                <div class="mt-auto pt-6 flex justify-between items-center text-bmkg">
                    <div onclick="navigate('aws', 1)" class="nav-btn hover:text-blue-800">
                        <i data-lucide="chevrons-left" class="w-4 h-4"></i> Previous
                    </div>
                    <div onclick="navigate('aws', -1)" id="btn-next-aws" class="nav-btn hover:text-blue-800 opacity-0 pointer-events-none">
                        Next <i data-lucide="chevrons-right" class="w-4 h-4"></i>
                    </div>
                </div>
            </div>

            <div class="p-6 flex-1 bg-white">
                <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-x-3 gap-y-4">
                    <div class="data-item"><span class="label-text">Temp</span><div id="aws_temp" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">StaP</span><div id="aws_stap" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">RR6</span><div id="aws_rr6" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">RH</span><div id="aws_rh" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">Tn12</span><div id="aws_tn12" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">MSLP</span><div id="aws_mslp" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">RR03</span><div id="aws_rr03" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">DewP</span><div id="aws_dewp" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">Tx12</span><div id="aws_tx12" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">Ivar3</span><div id="aws_ivar3" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">RR06</span><div id="aws_rr06" class="value-box">-</div></div>
                    <div class="row-span-2 flex flex-col justify-center gap-3 pl-2">
						<div class="data-item"><span class="label-text">Wind S</span><div id="aws_10min_winds" class="value-box">-</div></div>
                        <div class="data-item"><span class="label-text">Wind D</span><div id="aws_10min_winddir" class="value-box">-</div></div>
   
                    </div>
                    <div class="data-item"><span class="label-text">Tn24</span><div id="aws_tn24" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">Var3s</span><div id="aws_var3s" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">RR12</span><div id="aws_rr12" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">Tx24</span><div id="aws_tx24" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">Var24</span><div id="aws_var24" class="value-box">-</div></div>
                    <div class="data-item"><span class="label-text">RR24</span><div id="aws_rr24" class="value-box">-</div></div>
                    <div class="data-item pl-2"><span class="label-text">Winds Max</span><div id="aws_10min_windsmax" class="value-box">-</div></div>
                    <div class="col-span-full flex flex-wrap justify-center items-center gap-20 mt-6 pt-6 border-t border-slate-100">
                        <div class="data-item"><span class="label-text">Glor24</span><div id="aws_glor24" class="value-box min-w-[140px]">-</div></div>
                        <div class="data-item"><span class="label-text">InsD24</span><div id="aws_insd24" class="value-box">-</div></div>
                    </div>
                </div>
            </div>
        </section>