import cv2
import numpy as np
import pytesseract
import os
import re

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
CONFIG_NUMERIC = r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789-'

# --- HELPER: SAFE READ (PENTING UNTUK WINDOWS) ---
def imread_safe(path, flag=cv2.IMREAD_COLOR):
    """
    Membaca gambar dengan cara aman (load bytes -> decode).
    Mencegah file terkunci (WinError 32).
    """
    try:
        with open(path, "rb") as f:
            bytes_data = f.read()
        arr = np.frombuffer(bytes_data, np.uint8)
        return cv2.imdecode(arr, flag)
    except Exception as e:
        # print(f"[WARN] Gagal baca gambar {path}: {e}")
        return None

# --- CONFIG OFFSET DENGAN TIPE DATA ---
roi_configs = [
    # Baris 1: Wind & Main Data
    {"tpl": "aws_anchor_Wind.png",  "ox": 59,  "oy": -5, "w": 60, "h": 40, "label": "aws_10min_winddir", "is_decimal": False},
    {"tpl": "aws_anchor_Wind.png",  "ox": 120, "oy": -5, "w": 65, "h": 40, "label": "aws_10min_winds",   "is_decimal": True},
    {"tpl": "aws_anchor_Wind.png",  "ox": 192, "oy": -5, "w": 65, "h": 40, "label": "aws_10min_windsmax","is_decimal": True},
    {"tpl": "aws_anchor_StaP.png",  "ox": 42,  "oy": -5, "w": 76, "h": 40, "label": "aws_stap",          "is_decimal": True},
    {"tpl": "aws_anchor_StaP.png",  "ox": 174, "oy": -5, "w": 76, "h": 40, "label": "aws_temp",          "is_decimal": True},
    {"tpl": "aws_anchor_DP.png",    "ox": 34,  "oy": -5, "w": 76, "h": 40, "label": "aws_dewp",          "is_decimal": True},
    {"tpl": "aws_anchor_RH.png",    "ox": 24,  "oy": -5, "w": 76, "h": 40, "label": "aws_rh",            "is_decimal": False},
    {"tpl": "aws_anchor_RR6.png",   "ox": 36,  "oy": -5, "w": 76, "h": 40, "label": "aws_rr6",           "is_decimal": True},
    
    # Kolom 1: Weather & Gust
    {"tpl": "aws_anchor_Gust1.png", "ox": 43,  "oy": -4, "w": 34, "h": 39, "label": "aws_10gusth",       "is_decimal": False},
    {"tpl": "aws_anchor_Gust1.png", "ox": 81,  "oy": -4, "w": 49, "h": 39, "label": "aws_fxi",           "is_decimal": True},
    {"tpl": "aws_anchor_Gust3.png", "ox": 45,  "oy": -5, "w": 34, "h": 39, "label": "aws_10gust3h",      "is_decimal": False},
    {"tpl": "aws_anchor_Gust3.png", "ox": 82,  "oy": -5, "w": 49, "h": 39, "label": "aws_fxi3h",         "is_decimal": True},
    {"tpl": "aws_anchor_Gust6.png", "ox": 45,  "oy": -5, "w": 34, "h": 39, "label": "aws_10gust6h",      "is_decimal": False},
    {"tpl": "aws_anchor_Gust6.png", "ox": 81,  "oy": -5, "w": 49, "h": 39, "label": "aws_fxi6h",         "is_decimal": True},
    
    # Kolom 2: Pressure Trends
    {"tpl": "aws_anchor_MSLP.png",  "ox": 50,  "oy": -5, "w": 86, "h": 40, "label": "aws_mslp",          "is_decimal": True},
    {"tpl": "aws_anchor_Trend3.png","ox": 52,  "oy": -3, "w": 24, "h": 40, "label": "aws_ivar3",         "is_decimal": False},
    {"tpl": "aws_anchor_Trend3.png","ox": 76,  "oy": -3, "w": 60, "h": 40, "label": "aws_var3s",         "is_decimal": True},
    {"tpl": "aws_anchor_Var24.png", "ox": 48,  "oy": -5, "w": 86, "h": 40, "label": "aws_var24",         "is_decimal": True},
    
    # Kolom 3: Temperature Extremes
    {"tpl": "aws_anchor_Tn12.png",  "ox": 53,  "oy": -5, "w": 80, "h": 40, "label": "aws_tn12",          "is_decimal": True},
    {"tpl": "aws_anchor_Tn24.png",  "ox": 53,  "oy": -5, "w": 80, "h": 40, "label": "aws_tn24",          "is_decimal": True},
    {"tpl": "aws_anchor_Tx12.png",  "ox": 53,  "oy": -5, "w": 80, "h": 40, "label": "aws_tx12",          "is_decimal": True},
    {"tpl": "aws_anchor_Tx24.png",  "ox": 53,  "oy": -5, "w": 80, "h": 40, "label": "aws_tx24",          "is_decimal": True},
    
    # Kolom 4: Rain & Solar
    {"tpl": "aws_anchor_RR03.png",  "ox": 55,  "oy": -5, "w": 80, "h": 40, "label": "aws_rr03",          "is_decimal": True},
    {"tpl": "aws_anchor_RR06.png",  "ox": 55,  "oy": -5, "w": 80, "h": 40, "label": "aws_rr06",          "is_decimal": True},
    {"tpl": "aws_anchor_RR12.png",  "ox": 55,  "oy": -5, "w": 80, "h": 40, "label": "aws_rr12",          "is_decimal": True},
    {"tpl": "aws_anchor_RR24.png",  "ox": 55,  "oy": -5, "w": 80, "h": 40, "label": "aws_rr24",          "is_decimal": True},
    {"tpl": "aws_anchor_InsD24.png","ox": 56,  "oy": -5, "w": 83, "h": 40, "label": "aws_insd24",        "is_decimal": False},
    {"tpl": "aws_anchor_Glor24.png", "ox": 56,  "oy": -5, "w": 83, "h": 40, "label": "aws_glor24",        "is_decimal": False},
]

def pre_process_aws(img_gray_crop):
    # 1. Resize agar piksel teks lebih besar (lebih mudah dibaca Tesseract)
    img_roi = cv2.resize(img_gray_crop, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)
    
    # 2. Blur tipis untuk menghaluskan tepi huruf (anti-aliasing)
    img_roi = cv2.GaussianBlur(img_roi, (3, 3), 0)
    
    # 3. Ganti Adaptive Threshold dengan Otsu's Threshold.
    # Sangat efektif untuk gambar UI karena kontras warna hitam/putih solid.
    _, img_bin = cv2.threshold(img_roi, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    
    # 4. Pastikan background selalu putih (255) dan teks hitam (0)
    if img_bin[0, 0] == 0:
        img_bin = cv2.bitwise_not(img_bin)
        
    # HAPUS cv2.erode! 
    # Tanpa erosi, celah angka 3 dan 5 akan tetap terbuka. 
    # Kursor '|' juga akan tetap menjadi garis terpisah yang otomatis diabaikan Tesseract.
    
    # 5. Tambahkan padding/border putih
    img_bin = cv2.copyMakeBorder(img_bin, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
    
    return img_bin

def smart_format_value(raw_text, is_decimal):
    if raw_text is None: return None
    is_negative = '-' in raw_text
    digits = re.sub(r'\D', '', raw_text)
    if not digits: return None
    final_str = ""
    if not is_decimal:
        final_str = digits
    else:
        if len(digits) == 1:
            final_str = f"0.{digits}"
        else:
            main_part = digits[:-1]
            decimal_part = digits[-1]
            final_str = f"{main_part}.{decimal_part}"
    if is_negative:
        final_str = "-" + final_str
    return final_str

def extract_aws_data_from_image(img_rgb, templates_path):
    """Versi efisien: Input adalah gambar (numpy array), bukan path"""
    data = {}
    if img_rgb is None: return None

    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    
    # Loop config sama seperti sebelumnya...
    for config in roi_configs:
        tpl_path = os.path.join(templates_path, config['tpl'])
        if not os.path.exists(tpl_path):
            data[config['label']] = None; continue
            
        template = cv2.imread(tpl_path, 0)
        
        # OPTIMASI: Karena gambar input mungkin sudah di-CROP (kecil),
        # proses matchTemplate ini akan berjalan 4x-5x lebih cepat.
        res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)

        final_val = None
        if max_val >= 0.7:
            # Logika ekstraksi sama persis...
            ax, ay = max_loc
            vx = max(0, ax + config['ox'])
            vy = max(0, ay + config['oy'])
            vw, vh = config['w'], config['h']

            roi = img_gray[vy:vy+vh, vx:vx+vw]
            roi_proc = pre_process_aws(roi)
            raw_text = pytesseract.image_to_string(roi_proc, config=CONFIG_NUMERIC)
            
            # (Salin logika pembersihan data Anda di sini, sama persis)
            if (raw_text is None or raw_text.strip() == "") and config['label'] == 'aws_10min_winddir':
                 raw_text = "0"
            is_decimal = config.get('is_decimal', False)
            final_val = smart_format_value(raw_text, is_decimal)
            if config['label'] == 'aws_glor24' and final_val is not None:
                if len(final_val) < 8: final_val += "0"
                if len(final_val) > 8: final_val = final_val[:8]
        
        data[config['label']] = final_val

    return data
    
def extract_aws_data(image_path, templates_path):
    img = imread_safe(image_path)
    return extract_aws_data_from_image(img, templates_path)

def get_smart_crop_coords_from_image(img, templates_path):
    """Versi efisien: Menerima gambar yang sudah dibaca (numpy array)"""
    if img is None: return None

    tpl_path = os.path.join(templates_path, "aws_anchor_Wind.png")
    if not os.path.exists(tpl_path): return None
        
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    template = cv2.imread(tpl_path, 0)
    
    res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

    if max_val < 0.7: return None # Tidak ketemu anchor

    ax, ay = max_loc
    OFFSET_X = 45; OFFSET_Y = 55
    WINDOW_W = 1270; WINDOW_H = 480

    x1 = max(0, ax - OFFSET_X)
    y1 = max(0, ay - OFFSET_Y)
    x2 = min(img.shape[1], x1 + WINDOW_W)
    y2 = min(img.shape[0], y1 + WINDOW_H)

    return (y1, y2, x1, x2)