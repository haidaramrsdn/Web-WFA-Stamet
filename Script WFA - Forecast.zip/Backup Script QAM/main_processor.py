import os
import time
import shutil
import csv
import json
import datetime
import cv2
import glob
import threading
import numpy as np  # <--- TAMBAHKAN INI (PENTING)

# ... kode selanjutnya ...

# Import modul OCR (Pastikan file ocr_aws.py dan ocr_awos.py ada di folder yang sama)
try:
    import ocr_aws
    import ocr_awos
except ImportError as e:
    print(f"[CRITICAL ERROR] Modul OCR tidak ditemukan: {e}")
    print("Pastikan file 'ocr_aws.py' dan 'ocr_awos.py' ada di folder F:\\Data AWS AWOS")
    exit()

# --- 1. KONFIGURASI PATH ---
# Folder kerja utama
BASE_DIR = r'F:\\'

PATH_TEMPLATES = os.path.join(BASE_DIR,'Data AWS AWOS', 'templates')
JSON_DIR = os.path.join(BASE_DIR, 'json_data') 

# Pastikan folder output ada
os.makedirs(JSON_DIR, exist_ok=True)

DIRS = {
    'AWS': {
        'input': os.path.join(BASE_DIR, 'Data AWS AWOS','AWS', 'images'),
        'scanned': os.path.join(BASE_DIR, 'Data AWS AWOS', 'AWS', 'images', 'scanned'),
        'csv': os.path.join(BASE_DIR,'Data AWS AWOS', 'csv', 'aws_data.csv'),
        'ocr_func': ocr_aws.extract_aws_data,
        'prefix': 'aws_'
    },
    'AWOS': {
        'input': os.path.join(BASE_DIR, 'Data AWS AWOS','AWOS', 'images'),
        'scanned': os.path.join(BASE_DIR,'Data AWS AWOS', 'AWOS', 'images', 'scanned'),
        'csv': os.path.join(BASE_DIR,'Data AWS AWOS', 'csv', 'awos_data.csv'),
        'ocr_func': ocr_awos.extract_awos_data,
        'prefix': 'awos_'
    }
}

RETENTION_LIMIT = 720 # Simpan data gambar selama 24 jam
SLEEP_INTERVAL = 2

# --- 2. FUNGSI UTILITY ---

def parse_timestamp_from_filename(filename):
    try:
        base = os.path.splitext(filename)[0]
        parts = base.split('_')
        date_part = next((p for p in parts if len(p) == 8 and p.isdigit()), None)
        time_part = next((p for p in parts if len(p) == 6 and p.isdigit()), None)
        if date_part and time_part:
            return datetime.datetime.strptime(f"{date_part}_{time_part}", "%Y%m%d_%H%M%S")
        else:
            return datetime.datetime.now()
    except Exception:
        return datetime.datetime.now()

def check_file_ready(filepath):
    """
    Memastikan file sudah SELESAI ditulis oleh aplikasi lain.
    Caranya: Cek ukuran file, tunggu sebentar, cek lagi. Jika berubah, berarti masih ditulis.
    Juga mencoba membuka file dalam mode append untuk cek lock.
    """
    if not os.path.exists(filepath): return False
    
    try:
        # Cek 1: Apakah file 0 bytes?
        size1 = os.path.getsize(filepath)
        if size1 == 0: return False

        # Tunggu 1 detik (beri waktu aplikasi AWS menulis)
        time.sleep(1)

        # Cek 2: Apakah ukuran berubah?
        size2 = os.path.getsize(filepath)
        if size1 != size2:
            # Ukuran berubah, berarti sedang proses tulis. JANGAN PROSES DULU.
            return False

        # Cek 3: Coba Rename ke nama sendiri (Cara ampuh cek Lock di Windows)
        # Jika file sedang dipakai program lain, perintah ini akan error.
        os.rename(filepath, filepath)
        
        return True
        
    except OSError:
        # Jika error (Permission denied), berarti file masih dikunci aplikasi lain
        return False
    except Exception:
        return False

def save_to_csv(filepath, data_dict, timestamp_obj):
    if not data_dict: return
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file_exists = os.path.isfile(filepath)
    row = {'timestamp': timestamp_obj.strftime("%Y-%m-%d %H:%M:%S")}
    row.update(data_dict)
    fieldnames = ['timestamp'] + list(data_dict.keys())
    try:
        with open(filepath, mode='a', newline='') as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            if not file_exists: writer.writeheader()
            writer.writerow(row)
    except PermissionError:
        print(f"[ERR-CSV] File CSV sedang dibuka: {filepath}")

# --- Update fungsi ini di main_processor.py ---

# --- Update fungsi ini di main_processor.py ---

def save_processed_image(img_data, dest_folder, filename):
    """
    Menyimpan data gambar yang SUDAH ada di memori (RAM) ke folder tujuan.
    Tidak perlu membaca ulang dari disk.
    """
    if not os.path.exists(dest_folder): os.makedirs(dest_folder)
    
    new_filename = os.path.splitext(filename)[0] + ".jpg"
    dest_path = os.path.join(dest_folder, new_filename)
    
    try:
        # Simpan langsung dari memori dengan kompresi JPG 
        cv2.imwrite(dest_path, img_data, [int(cv2.IMWRITE_JPEG_QUALITY), 10])
        return new_filename
    except Exception as e:
        print(f"[ERR-SAVE] Gagal menyimpan {filename}: {e}")
        return None
       
        
def maintain_retention(folder_path, limit):
    """Menghapus file lama jika melebihi batas"""
    try:
        files = glob.glob(os.path.join(folder_path, "*"))
        if len(files) <= limit: return
        files.sort(key=os.path.getmtime)
        for i in range(len(files) - limit):
            try: os.remove(files[i])
            except OSError: pass
    except Exception: pass

# --- 3. FUNGSI UPDATE DATA WEB (JSON) ---

def write_json_atomic(filepath, data):
    """Menulis JSON dengan aman (temp file)"""
    temp_path = filepath + ".tmp"
    try:
        with open(temp_path, 'w') as f:
            json.dump(data, f)
        shutil.move(temp_path, filepath)
    except Exception as e:
        print(f"[ERR-JSON] Gagal tulis JSON: {e}")

def update_web_json(data_dict, jpg_filename, source_type):
    """
    Update file JSON yang akan dibaca oleh website.
    """
    # Path relative untuk website: AWS/images/scanned/namafile.jpg
    web_image_path = f"Data AWS AWOS/{source_type}/images/scanned/{jpg_filename}"
    data_dict['original_image'] = web_image_path
    
    # 1. Update LATEST (Data Terkini)
    latest_file = os.path.join(JSON_DIR, f"{source_type.lower()}_latest.json")
    write_json_atomic(latest_file, data_dict)
    
    # 2. Update HISTORY (Data 24 Jam / 1440 baris)
    history_file = os.path.join(JSON_DIR, f"{source_type.lower()}_history.json")
    history = []
    if os.path.exists(history_file):
        try:
            with open(history_file, 'r') as f: history = json.load(f)
        except: history = []
        
    history.insert(0, data_dict)
    if len(history) > RETENTION_LIMIT:
        history = history[:RETENTION_LIMIT]
        
    write_json_atomic(history_file, history)



# UPDATE WORKER PROCESS
def worker_process(config_key):
    cfg = DIRS[config_key]
    print(f"[{config_key}] Memantau Folder: {cfg['input']}")
    os.makedirs(cfg['scanned'], exist_ok=True)

    while True:
        try:
            if not os.path.exists(cfg['input']):
                time.sleep(SLEEP_INTERVAL); continue

            # Ambil list file
            files = [f for f in os.listdir(cfg['input']) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
            if not files:
                time.sleep(SLEEP_INTERVAL); continue
            
            files.sort()

            for filename in files:
                src_path = os.path.join(cfg['input'], filename)
                
                if not check_file_ready(src_path): continue

                print(f"[{config_key}] Memproses: {filename}")
                
                try:
                    ts = parse_timestamp_from_filename(filename)
                    
                    # --- 1. BACA FILE KE MEMORI (Cuma 1 kali akses disk!) ---
                    # Kita pakai fungsi imread_safe dari ocr_aws agar konsisten
                    img_raw = ocr_aws.imread_safe(src_path)
                    
                    if img_raw is None:
                        print(f"[WARN] File corrupt/gagal baca: {filename}")
                        try: os.remove(src_path) # Hapus atau pindahkan ke error
                        except: pass
                        continue

                    # --- 2. SMART CROP (Dilakukan di RAM) ---
                    img_to_process = img_raw # Default pakai gambar asli
                    
                    if config_key == 'AWS':
                        # Kita modifikasi get_smart_crop_coords agar menerima IMAGE OBJECT, bukan path
                        crop_box = ocr_aws.get_smart_crop_coords_from_image(img_raw, PATH_TEMPLATES)
                        
                        if crop_box:
                            y1, y2, x1, x2 = crop_box
                            img_to_process = img_raw[y1:y2, x1:x2] # Crop di memori
                    
                    # --- 3. OCR (Jauh lebih cepat karena scan area kecil) ---
                    # Kita modifikasi fungsi OCR agar menerima IMAGE OBJECT
                    if config_key == 'AWS':
                        ocr_result = ocr_aws.extract_aws_data_from_image(img_to_process, PATH_TEMPLATES)
                    else:
                        ocr_result = ocr_awos.extract_awos_data_from_image(img_to_process, PATH_TEMPLATES)

                    # --- 4. SIMPAN GAMBAR HASIL ---
                    # Simpan gambar yang sudah dicrop/diproses
                    final_jpg_name = save_processed_image(img_to_process, cfg['scanned'], filename)
                    
                    if ocr_result and final_jpg_name:
                        ocr_result['timestamp'] = ts.strftime("%Y-%m-%d %H:%M:%S")
                        save_to_csv(cfg['csv'], ocr_result, ts)
                        update_web_json(ocr_result, final_jpg_name, config_key)
                        print(f"[{config_key}] Selesai.")

                    # --- 5. BERSIHKAN SOURCE ---
                    # Hapus file asli di folder input
                    try:
                        os.remove(src_path)
                    except OSError:
                        pass # File locking issue, abaikan sesaat

                    maintain_retention(cfg['scanned'], RETENTION_LIMIT)

                except Exception as e:
                    print(f"[{config_key}] ERROR pada {filename}: {e}")
                    # Pindahkan file bermasalah agar tidak looping
                    try: shutil.move(src_path, os.path.join(cfg['scanned'], "ERROR_"+filename))
                    except: pass

        except Exception as main_e:
            print(f"[{config_key}] LOOP ERROR: {main_e}")
            time.sleep(5)
            
# --- ENTRY POINT ---
if __name__ == "__main__":
    print("=== MONITORING SYSTEM STARTED (DRIVE F:) ===")
    
    t_aws = threading.Thread(target=worker_process, args=('AWS',))
    t_awos = threading.Thread(target=worker_process, args=('AWOS',))

    t_aws.daemon = True
    t_awos.daemon = True

    t_aws.start()
    t_awos.start()

    try:
        while True: time.sleep(1)
    except KeyboardInterrupt:
        print("\nBerhenti...")