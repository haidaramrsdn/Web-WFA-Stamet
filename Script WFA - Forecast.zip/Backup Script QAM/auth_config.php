<?php
session_start();

// --- KONFIGURASI ---
define('ADMIN_PASSWORD', '123'); 

// (Opsional) Konstanta ini tidak lagi digunakan untuk validasi, tapi dibiarkan agar tidak error jika ada file lain yang memanggilnya
define('SESSION_FILE', 'current_session.token');

function checkLoginStatus() {
    // Cek apakah user punya sesi di browser
    if (!isset($_SESSION['login_token'])) {
        return false;
    }

    // --- BAGIAN INI DIHAPUS/KOMENTAR ---
    // Kita tidak lagi membandingkan token browser dengan server
    // agar banyak user bisa login dengan token berbeda-beda secara bersamaan.
    
    /* if (file_exists(SESSION_FILE)) {
        $server_token = file_get_contents(SESSION_FILE);
        if ($_SESSION['login_token'] === $server_token) {
            return true; 
        }
    }
    return false; 
    */
    
    // Langsung return true jika sesi ada
    return true; 
}
?>