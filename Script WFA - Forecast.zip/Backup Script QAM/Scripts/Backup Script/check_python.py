import os

# Ganti 'F:\\' dengan '\\172.21.80.69\web' jika Anda sudah memakai IP
BASE_DIR = r'F:\\' 
FOLDER_PATH = os.path.join(BASE_DIR, 'json_data')
QUEUE_FILE = os.path.join(FOLDER_PATH, 'qam_queue.json')

print("=== DIAGNOSTIK PYTHON ===")
print(f"1. Target File    : {QUEUE_FILE}")
print(f"2. File Ditemukan?: {os.path.exists(QUEUE_FILE)}")

print("\n3. Coba intip isi folder json_data...")
try:
    isi_folder = os.listdir(FOLDER_PATH)
    print(f"   SUKSES BACA! Ada {len(isi_folder)} file di dalam.")
    if 'qam_queue.json' in isi_folder:
        print("   -> File 'qam_queue.json' TERLIHAT di dalam list!")
    else:
        print("   -> File 'qam_queue.json' GAIB (Tidak ada di list).")
except Exception as e:
    print(f"   GAGAL BACA FOLDER! Error: {e}")
print("=========================")