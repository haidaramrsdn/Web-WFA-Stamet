// Inisialisasi Icon Lucide
lucide.createIcons();

// Jam Realtime
function updateClock() {
    const now = new Date();
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];
    const elDate = document.getElementById('top-date');
    const elClock = document.getElementById('top-clock');
    if (elDate && elClock) {
        elDate.innerText = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
        const h = (n) => String(n).padStart(2, '0');
        const timeWIT = `${h(now.getHours())}:${h(now.getMinutes())}:${h(now.getSeconds())}`;
        const timeUTC = `${h(now.getUTCHours())}:${h(now.getUTCMinutes())}:${h(now.getUTCSeconds())}`;
        elClock.innerHTML = `${timeWIT} <span class="text-sm font-bold text-slate-500">WIT</span> <span class="text-slate-300 mx-1">/</span> ${timeUTC} <span class="text-sm font-bold text-slate-500">UTC</span>`;
    }
}
setInterval(updateClock, 1000);
updateClock();

// Modal Image
function closeModal() {
    document.getElementById('imageModal').classList.add('hidden');
    document.getElementById('modalImage').src = "";
}

// Tab Switching
function switchTab(tabName) {
    const contentMain = document.getElementById('content-main');
    const contentBlank = document.getElementById('content-blank');
    const sectionQam = document.getElementById('section-qam');
    const blankTitle = document.getElementById('blank-title');
    
    // Reset Navigasi
    ['main', 'visibility', 'me48', 'forecast', 'qam'].forEach(btn => {
        document.getElementById('btn-' + btn).className = "tab-inactive px-5 py-2 rounded-full font-bold text-sm transition-all cursor-pointer";
    });
    document.getElementById('btn-' + tabName).className = "tab-active px-5 py-2 rounded-full font-bold text-sm transition-all cursor-pointer transform active:scale-95";

    // Sembunyikan Konten
    if(contentMain) contentMain.classList.add('hidden');
    if(contentBlank) contentBlank.classList.add('hidden');
    if(sectionQam) sectionQam.classList.add('hidden');

    // Logika Tab
    if (tabName === 'main') { 
        if(contentMain) contentMain.classList.remove('hidden'); 
    } else if (tabName === 'qam') {
        if(sectionQam) sectionQam.classList.remove('hidden');
        
        // PANGGIL LOGIKA QAM SAAT TAB DIKLIK (Persis seperti index.html Anda!)
        if (typeof initQAMTab === 'function') {
            initQAMTab();
        }
        
    } else { 
        if(contentBlank) contentBlank.classList.remove('hidden'); 
        if(blankTitle) blankTitle.innerText = {'visibility': 'Visibility Data', 'me48': 'ME48/45 Data', 'forecast': 'Weather Forecast'}[tabName]; 
    }
}


// Cek status setiap 3 detik (biar lebih cepat)
setInterval(async () => {
    try {
        // Pakai timestamp ?t= agar tidak di-cache browser
        const url = 'check_session.php?t=' + Date.now();
        const req = await fetch(url);
        const data = await req.json();

        // Debugging di Console (Tekan F12 untuk lihat)
        console.log("Cek Sesi:", data); 

        if (data.valid === false) {
            console.warn("KICKED! Server token:", data.debug_server, "User token:", data.debug_user);
            
            // Panggil Modal Warning (jika sudah dibuat) atau langsung redirect
            if (typeof triggerKickUI === 'function') {
                triggerKickUI(); 
            } else {
                alert("Perangkat lain telah login. Anda akan keluar.");
                window.location.href = 'login.php';
            }
        }
    } catch (e) {
        console.error("Gagal koneksi ke server check_session");
    }
}, 3000);


// --- SISTEM AUTO KICK / SINGLE SESSION ---
// Variabel untuk menyimpan ID interval agar bisa dimatikan
let sessionCheckInterval = null;

function checkSessionStatus() {
    fetch('check_auth.php', { cache: "no-store" }) // Tambahkan no-store agar tidak dicache browser
        .then(response => {
            if (!response.ok) throw new Error("Network response was not ok");
            return response.json();
        })
        .then(data => {
            // Jika status kicked atau sesi tidak valid
            if (data.status !== 'active') {
                // 1. Matikan interval pengecekan ini sendiri agar tidak loop
                if (sessionCheckInterval) clearInterval(sessionCheckInterval);
                
                // 2. (Opsional) Coba matikan interval data fetching di aws-awos.js jika variabelnya global
                // Tapi biasanya langkah no. 3 sudah cukup mematikan semuanya.

                // 3. LANGSUNG LEMPAR ke Login tanpa masuk History Browser
                // Menggunakan 'replace' membuat user tidak bisa menekan tombol Back
                window.location.replace('login.php?kicked=1');
            }
        })
        .catch(err => {
            // Jika fetch error (misal koneksi putus), biarkan dulu atau redirect juga
            console.error("Gagal cek sesi:", err);
        });
}

// Jalankan pengecekan setiap 3 detik (lebih cepat lebih responsif)
sessionCheckInterval = setInterval(checkSessionStatus, 3000);