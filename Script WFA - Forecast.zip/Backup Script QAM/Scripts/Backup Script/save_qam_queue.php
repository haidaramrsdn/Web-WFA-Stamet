<?php
// save_qam_queue.php

// Izinkan akses dari script JS
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $_POST['message'] ?? '';
    
    if (!empty($message)) {
        // Path ke folder json_data (Sesuaikan jika perlu)
        $file_path = 'json_data/qam_queue.json';
        
        // Data yang akan dibaca Python
        $data = [
            'timestamp' => date('Y-m-d H:i:s'),
            'message' => $message
        ];
        
        // Simpan file
        if (file_put_contents($file_path, json_encode($data))) {
            echo "OK";
        } else {
            http_response_code(500);
            echo "Gagal menulis file";
        }
    } else {
        http_response_code(400);
        echo "Pesan kosong";
    }
}
?>