<section id="section-qam" class="hidden max-w-6xl mx-auto mb-12">
    <div class="bg-white rounded-xl shadow-xl border-t-[6px] border-orange-500 overflow-hidden ring-1 ring-slate-900/5">
        
        <div class="px-6 py-4 border-b border-slate-200 bg-slate-50/80 backdrop-blur flex justify-between items-center">
            <h2 class="text-2xl font-black text-slate-700 flex items-center gap-3 tracking-tight">
                <div class="p-2 bg-orange-100 text-orange-600 rounded-lg">
                    <i data-lucide="message-square-plus" class="w-6 h-6"></i>
                </div>
                GENERATE MET REPORT
            </h2>
            <div class="text-xs font-bold font-mono tracking-wider bg-orange-100 text-orange-700 px-3 py-1.5 rounded-full border border-orange-200">
                QAM / WA BLAST
            </div>
        </div>

        <div class="p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <div class="lg:col-span-5 space-y-5">
                
                <div class="bg-blue-50/50 p-4 rounded-xl border border-blue-100 space-y-2">
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider">Observer on Duty</label>
                    <div class="relative">
                        <i data-lucide="user" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-400"></i>
                        <input type="text" id="qam-observer" placeholder="Nama Observer..." 
                            class="w-full pl-10 pr-4 h-11 border border-blue-200 rounded-lg text-base font-semibold text-slate-700 focus:ring-4 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all placeholder:font-normal">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Date (UTC)</label>
                        <input type="date" id="qam-date" onchange="updateQAMSensor()" 
                            class="w-full h-11 px-3 border border-slate-300 rounded-lg text-base font-mono text-slate-700 focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 outline-none cursor-pointer transition-all bg-white">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Time (UTC)</label>
                        <input type="time" id="qam-time" onchange="updateQAMSensor()" 
                            class="w-full h-11 px-3 border border-slate-300 rounded-lg text-base font-mono text-slate-700 focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 outline-none cursor-pointer transition-all bg-white">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Visibility (KM)</label>
                        <input type="text" id="qam-vis" placeholder="10" 
                            class="w-full h-11 px-3 border border-slate-300 rounded-lg text-base font-medium text-slate-700 focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Present Wx</label>
                        <input type="text" id="qam-wx" value="NIL" 
                            class="w-full h-11 px-3 border border-slate-300 rounded-lg text-base font-medium text-slate-700 focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Cloud</label>
                        <input type="text" id="qam-cloud" placeholder="FEW018 CB" 
                            class="w-full h-11 px-3 border border-slate-300 rounded-lg text-base font-medium text-slate-700 focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Trend</label>
                        <input type="text" id="qam-trend" value="NOSIG" 
                            class="w-full h-11 px-3 border border-slate-300 rounded-lg text-base font-medium text-slate-700 focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">Supp Info</label>
                    <input type="text" id="qam-supp" value="-" 
                        class="w-full h-11 px-3 border border-slate-300 rounded-lg text-base font-medium text-slate-700 focus:ring-4 focus:ring-orange-500/20 focus:border-orange-500 outline-none placeholder-slate-300 transition-all" placeholder="RMK...">
                </div>

                <div class="grid grid-cols-2 gap-3 pt-4 border-t border-slate-200 border-dashed">
                    <button onclick="checkImageFromQAM('aws')" 
                        class="h-10 flex items-center justify-center gap-2 text-sm font-bold text-bmkg bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-all active:scale-95">
                        <i data-lucide="image" class="w-4 h-4"></i> CHECK AWS
                    </button>
                    <button onclick="checkImageFromQAM('awos')" 
                        class="h-10 flex items-center justify-center gap-2 text-sm font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-all active:scale-95">
                        <i data-lucide="image" class="w-4 h-4"></i> CHECK AWOS
                    </button>
                </div>
            </div>

            <div class="lg:col-span-3 bg-slate-50 p-5 rounded-xl border border-slate-200 flex flex-col gap-4">
                <div class="pb-3 border-b border-slate-200">
                    <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest">Sensor Data</h3>
                </div>
                
                <div>
                    <label class="block text-[11px] font-bold text-slate-500 uppercase mb-1">Wind (Dir/Spd)</label>
                    <div class="flex gap-2">
                        <input type="text" id="qam-wind-dir" placeholder="ddd" 
                            class="w-full h-10 border border-slate-300 rounded-lg text-center text-base font-mono font-bold text-blue-700 focus:ring-2 focus:ring-orange-500 outline-none">
                        <span class="text-slate-300 font-light text-2xl">/</span>
                        <input type="text" id="qam-wind-spd" placeholder="ff" 
                            class="w-full h-10 border border-slate-300 rounded-lg text-center text-base font-mono font-bold text-blue-700 focus:ring-2 focus:ring-orange-500 outline-none">
                    </div>
                </div>

                <div>
                    <label class="block text-[11px] font-bold text-slate-500 uppercase mb-1">Temp (T)</label>
                    <div class="relative">
                        <input type="text" id="qam-temp" placeholder="-" 
                            class="w-full h-10 pl-3 pr-8 border border-slate-300 rounded-lg text-base font-mono font-bold text-blue-700 focus:ring-2 focus:ring-orange-500 outline-none">
                        <span class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">°C</span>
                    </div>
                </div>

                <div>
                    <label class="block text-[11px] font-bold text-slate-500 uppercase mb-1">Dew Point (Td)</label>
                    <div class="relative">
                        <input type="text" id="qam-dew" placeholder="-" 
                            class="w-full h-10 pl-3 pr-8 border border-slate-300 rounded-lg text-base font-mono font-bold text-blue-700 focus:ring-2 focus:ring-orange-500 outline-none">
                        <span class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">°C</span>
                    </div>
                </div>

                <div>
                    <label class="block text-[11px] font-bold text-slate-500 uppercase mb-1">Humidity (RH)</label>
                    <div class="relative">
                        <input type="text" id="qam-rh" placeholder="-" 
                            class="w-full h-10 pl-3 pr-8 border border-slate-300 rounded-lg text-base font-mono font-bold text-blue-700 focus:ring-2 focus:ring-orange-500 outline-none">
                        <span class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">%</span>
                    </div>
                </div>

                <div>
                    <label class="block text-[11px] font-bold text-slate-500 uppercase mb-1">QNH (hPa)</label>
                    <input type="number" step="0.1" id="qam-qnh" placeholder="1010.5" 
                        class="w-full h-10 px-3 border border-slate-300 rounded-lg text-base font-mono font-bold text-blue-700 focus:ring-2 focus:ring-orange-500 outline-none">
                    <p class="text-[10px] text-slate-500 mt-1.5 leading-tight">*QFE & inHg akan dihitung otomatis.</p>
                </div>

				<div class="mt-auto pt-2">
					<button onclick="refreshSensorData()" 
						class="w-full py-2.5 text-xs font-bold bg-white border border-slate-300 hover:bg-slate-100 hover:text-slate-800 text-slate-600 rounded-lg transition shadow-sm flex items-center justify-center gap-2 active:scale-95">
						<i data-lucide="download-cloud" class="w-4 h-4"></i> Fetch Data
					</button>
				</div>
            </div>

            <div class="lg:col-span-4 flex flex-col h-full">
                <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Preview Pesan</label>
                
                <textarea id="qam-result" 
                    class="w-full flex-1 min-h-[450px] border border-slate-300 rounded-xl p-4 text-sm font-mono leading-relaxed bg-slate-900 text-green-400 mb-4 focus:outline-none focus:ring-4 focus:ring-orange-500/30 resize-none shadow-inner" 
                    placeholder="Klik Generate untuk melihat hasil..."></textarea>
                
                <div class="flex flex-col gap-3">
                    <div class="flex gap-3">
                        <button onclick="generateQAM()" 
                            class="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-xl shadow-lg shadow-orange-500/20 transition-all active:scale-95 text-sm flex items-center justify-center gap-2">
                            <i data-lucide="refresh-cw" class="w-5 h-5"></i> Generate
                        </button>
                        <button onclick="sendAndCopyQAM()" id="btn-send-qam" 
                            class="flex-[1.5] bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-green-600/20 transition-all active:scale-95 text-sm flex items-center justify-center gap-2">
                            <i data-lucide="send" class="w-5 h-5"></i> Send & Copy
                        </button>
                    </div>
                    <div id="copy-status" class="text-center text-xs font-bold text-green-600 h-4 opacity-0 transition-opacity">
                        <span class="flex items-center justify-center gap-1"><i data-lucide="check-circle" class="w-3 h-3"></i> Pesan tersalin & terkirim!</span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>