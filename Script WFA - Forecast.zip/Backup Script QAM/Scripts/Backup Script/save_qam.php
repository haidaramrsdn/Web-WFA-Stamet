<?php
// save_qam.php
// Letakkan di folder web Synology (F:\...)

// Izinkan akses dari PC manapun (CORS)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

// Aktifkan error reporting untuk debugging
ini_set('display_errors', 0); // Jangan tampilkan error HTML ke JSON
error_reporting(E_ALL);

$response = array();

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Request harus metode POST.');
    }

    $message = $_POST['message'] ?? '';
    
    if (empty($message)) {
        throw new Exception('Pesan kosong.');
    }

    // Path folder json_data
    // __DIR__ mengacu pada folder di dalam Synology (/volume1/web/...)
    $dir = __DIR__ . '/json_data';
    $file = $dir . '/qam_queue.json';

    // Cek Permission Folder
    if (!is_dir($dir)) {
        if (!mkdir($dir, 0777, true)) {
            throw new Exception("Gagal buat folder. Cek Permission Synology.");
        }
    }
    
    if (!is_writable($dir)) {
        // Ini error yang paling sering terjadi saat akses dari PC lain
        throw new Exception("Folder 'json_data' terkunci (Read-Only). Ubah Permission di File Station Synology menjadi R/W untuk 'Everyone'.");
    }

    $data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'message' => $message,
        'status' => 'pending'
    ];
    
    // Tulis File
    if (file_put_contents($file, json_encode($data))) {
        $response['status'] = 'success';
    } else {
        throw new Exception("Gagal menulis file JSON.");
    }

} catch (Exception $e) {
    http_response_code(500);
    $response['status'] = 'error';
    $response['msg'] = $e->getMessage();
}

echo json_encode($response);
?>