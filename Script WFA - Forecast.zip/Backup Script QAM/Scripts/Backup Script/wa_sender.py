import time
import json
import os
import pyautogui
import pyperclip
import pygetwindow as gw

# --- KONFIGURASI ---
BASE_DIR = r'F:\\' 
QUEUE_FILE = os.path.join(BASE_DIR, 'json_data', 'qam_queue.json')

# ASSETS GAMBAR
# 1. Validasi Nama Grup (Agar tidak salah kirim)
VALIDATION_IMAGE = os.path.join(BASE_DIR, 'web_assets', 'validation_wagroupname.png') 
# 2. Target Klik (Kotak Ketik Pesan) - BARU
MESSAGE_BOX_IMAGE = os.path.join(BASE_DIR, 'web_assets', 'message_box.png')

def is_whatsapp_focused():
    """Cek apakah jendela aktif adalah WhatsApp"""
    active_window = gw.getActiveWindow()
    if active_window and "WhatsApp" in active_window.title:
        return True
    return False

def verify_and_send(message):
    """
    1. Cek Validasi Grup.
    2. Jika valid, cari kotak pesan -> Klik.
    3. Paste & Enter.
    4. Klik area kosong (Unfocus).
    """
    
    # Cek ketersediaan file gambar
    if not os.path.exists(VALIDATION_IMAGE):
        print(f"[ERROR] File '{VALIDATION_IMAGE}' hilang!")
        return False
    if not os.path.exists(MESSAGE_BOX_IMAGE):
        print(f"[WARNING] File '{MESSAGE_BOX_IMAGE}' hilang! Skrip mungkin kurang akurat.")

    # Fokuskan WhatsApp
    if not is_whatsapp_focused():
        try:
            windows = gw.getWindowsWithTitle('WhatsApp')
            if windows:
                win = windows[0]
                if win.isMinimized: win.restore()
                win.activate()
                time.sleep(1) 
        except:
            pass
            
    # --- TAHAP 1: VERIFIKASI GRUP ---
    print("Memindai layar untuk verifikasi grup...")
    try:
        # Cari Header Grup
        group_loc = pyautogui.locateOnScreen(VALIDATION_IMAGE, confidence=0.9, grayscale=True)
        
        if group_loc:
            print("[AMAN] Grup Valid Terdeteksi!")
            
            # --- TAHAP 2: KLIK KOTAK PESAN ---
            print("Mencari kotak input pesan...")
            try:
                # Cari gambar 'Ketik pesan'
                box_loc = pyautogui.locateOnScreen(MESSAGE_BOX_IMAGE, confidence=0.8, grayscale=True)
                
                if box_loc:
                    print("Kotak pesan ditemukan. Melakukan klik...")
                    # Klik tepat di tengah gambar 'Ketik pesan'
                    pyautogui.click(box_loc)
                else:
                    # FALLBACK: Jika gambar kotak pesan tidak ketemu
                    print("[INFO] Kotak pesan tidak terdeteksi visual. Menggunakan klik koordinat (Fallback).")
                    x, y, w, h = group_loc # Ambil koordinat header grup
                    # Klik 500 pixel di bawah header grup
                    pyautogui.click(x + (w/2), y + 500)
            
            except Exception as e:
                print(f"[NAV ERROR] Gagal klik kotak pesan: {e}")

            # Beri jeda sedikit setelah klik agar fokus masuk
            time.sleep(0.5)

            # --- TAHAP 3: KIRIM PESAN ---
            pyperclip.copy(message)
            time.sleep(0.3)
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(0.5)
            pyautogui.press('enter')
            print("[SUCCESS] Pesan terkirim.")

            # --- TAHAP 4: UNCLICK / UNFOCUS (MODIFIKASI) ---
            # Tujuannya agar status 'typing' hilang
            time.sleep(1) # Tunggu sebentar agar pesan benar-benar terkirim
            try:
                # Ambil posisi mouse saat ini (posisi terakhir ada di kotak pesan)
                cur_x, cur_y = pyautogui.position()
                
                # Geser mouse ke ATAS (Y dikurang) sejauh 200 pixel
                # Ini akan mengklik area background chat (kosong)
                print("Melepas fokus (Unclicking)...")
                pyautogui.click(cur_x, cur_y - 50)
                
                # Opsional: Geser mouse ke pojok agar tidak menghalangi pandangan
                # pyautogui.moveTo(10, 10) 
            except Exception as e:
                print(f"[UNCLICK ERROR] Gagal melepas fokus: {e}")

            return True
            
        else:
            print("[BAHAYA] Grup target TIDAK TERLIHAT di layar!")
            return False

    except Exception as e:
        print(f"[ERROR SCAN] {e}")
        return False

# --- MAIN LOOP ---
print("=== WA AUTO SENDER (SMART SAFE MODE + AUTO CLICK + UNFOCUS) ===")
print(f"Validasi Grup : {VALIDATION_IMAGE}")
print(f"Target Klik   : {MESSAGE_BOX_IMAGE}")
print("-" * 50)

while True:
    try:
        if os.path.exists(QUEUE_FILE):
            print(f"[NEW JOB] Mendeteksi antrian...")
            
            try:
                with open(QUEUE_FILE, 'r') as f:
                    data = json.load(f)
            except:
                os.remove(QUEUE_FILE); continue

            # EKSEKUSI
            if verify_and_send(data['message']):
                os.remove(QUEUE_FILE) # Hapus antrian jika sukses
                print("[DONE] Selesai.\n")
            else:
                print("[PENDING] Menunggu operator membuka grup yang benar...")
                time.sleep(5) 
        else:
            time.sleep(2)

    except Exception as e:
        print(f"[ERROR LOOP] {e}")
        time.sleep(5)