import pyautogui
import os
import time
from datetime import datetime, timedelta

# --- KONFIGURASI ---
OUTPUT_FOLDER = r"F:\Data AWS AWOS\AWS\images"  # Drive NAS
PREFIX_FILE = "aws"
INTERVAL_MINUTES = 2   # Interval dalam menit
CAPTURE_DELAY_SECONDS = 15  # <--- UBAH DISINI: Detik keterlambatan (misal 3 detik)

def take_screenshot():
    """Fungsi utama untuk mengambil gambar"""
    try:
        # Cek koneksi ke NAS
        if os.path.exists(OUTPUT_FOLDER):
            # Timestamp untuk nama file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{PREFIX_FILE}_{timestamp}.png"
            full_path = os.path.join(OUTPUT_FOLDER, filename)
            
            # Capture
            screenshot = pyautogui.screenshot()
            screenshot.save(full_path)
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Sukses capture: {filename}")
        else:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Folder tidak ditemukan: {OUTPUT_FOLDER}")
    except Exception as e:
        print(f"Error: {e}") 

def main():
    print(f"--- Program Berjalan ---")
    print(f"Target Folder: {OUTPUT_FOLDER}")
    print(f"Interval: Setiap {INTERVAL_MINUTES} menit")
    print(f"Delay Capture: +{CAPTURE_DELAY_SECONDS} detik dari jadwal")
    print("Menunggu jadwal capture berikutnya...")

    while True:
        now = datetime.now()
        
        # --- LOGIKA SINKRONISASI WAKTU DINAMIS ---
        remainder = now.minute % INTERVAL_MINUTES
        minutes_to_next_trigger = INTERVAL_MINUTES - remainder
        
        # 1. Tentukan target waktu dasar (tepat di :00)
        target_time = now + timedelta(minutes=minutes_to_next_trigger)
        target_time = target_time.replace(second=0, microsecond=0)
        
        # 2. Hitung selisih detik murni menuju :00
        seconds_to_sleep = (target_time - datetime.now()).total_seconds()
        
        # 3. Jika waktu sudah terlalu mepet atau lewat (misal kode berjalan pas di 13:40:00.1),
        #    tambahkan satu interval penuh agar tidak double trigger atau error.
        if seconds_to_sleep <= 0.5:
            seconds_to_sleep += (INTERVAL_MINUTES * 60)
            target_time += timedelta(minutes=INTERVAL_MINUTES)
            
        # --- PERUBAHAN UTAMA DI SINI ---
        # 4. Tambahkan delay wajib agar capture terjadi SETELAH :00
        #    Jadi program akan bangun tepat di target + 3 detik.
        final_sleep_time = seconds_to_sleep + CAPTURE_DELAY_SECONDS
        
        # (Opsional) Print info kapan akan bangun
        real_target = target_time + timedelta(seconds=CAPTURE_DELAY_SECONDS)
        # print(f"Menunggu hingga {real_target.strftime('%H:%M:%S')}...")
        
        time.sleep(final_sleep_time)
        
        # --- EKSEKUSI ---
        take_screenshot()
        
        # Tidur sebentar agar loop tidak berulang cepat
        time.sleep(2)

if __name__ == "__main__":
    main()