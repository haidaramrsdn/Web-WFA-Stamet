/**
 * Helper: Parse float aman
 */
function safeFloat(val) {
    if (!val) return null;
    const cleaned = String(val).replace(/[^\d.-]/g, '');
    const num = parseFloat(cleaned);
    return isNaN(num) ? null : num;
}

/**
 * LOGIKA WAKTU: Rounding Down (Floor) ke 30 Menit terdekat
 */
function getFlooredUTCTime() {
    const now = new Date();
    
    let h = now.getUTCHours();
    let m = now.getUTCMinutes();
    
    // Logika Floor 30 Menit
    if (m < 30) {
        m = 0;
    } else {
        m = 30;
    }

    const timeString = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    
    // Format Tanggal YYYY-MM-DD
    const y = now.getUTCFullYear();
    const mo = String(now.getUTCMonth() + 1).padStart(2, '0');
    const d = String(now.getUTCDate()).padStart(2, '0');
    const dateString = `${y}-${mo}-${d}`;

    return { date: dateString, time: timeString };
}

/**
 * Inisialisasi Tab QAM
 */
function initQAMTab() {
    // 1. Load Last State dari Server (User Input manual sebelumnya)
    fetch('json_data/qam_last_state.json?v=' + new Date().getTime())
        .then(response => response.json())
        .then(data => {
            const fields = ['observer', 'vis', 'wx', 'cloud', 'trend', 'supp'];
            fields.forEach(field => {
                if (data[field]) {
                    const el = document.getElementById('qam-' + field);
                    if(el) el.value = data[field];
                }
            });
        })
        .catch(err => console.log("Belum ada history server:", err));	

    // 2. Set Default Tanggal & Jam dengan Logika Floor (Kelipatan 30 menit)
    const calculated = getFlooredUTCTime();
    
    const elDate = document.getElementById('qam-date');
    const elTime = document.getElementById('qam-time');

    // Hanya set waktu jika input masih kosong (saat pertama load)
    if (elDate && !elDate.value) elDate.value = calculated.date;
    if (elTime && !elTime.value) elTime.value = calculated.time;

    // 3. Trigger Update Data Sensor (REVISI BUG RELOAD)
    // Langsung update (mungkin dapat data Latest dulu karena history belum load)
    updateQAMSensor();

    // Buat interval pengecekan:
    // Tunggu sampai `historyAWS` terisi banyak (artinya load background selesai)
    // Lalu paksa update sekali lagi agar data sesuai jam (bukan latest)
    let retryCount = 0;
    const checkHistoryLoaded = setInterval(() => {
        retryCount++;
        // Cek apakah historyAWS sudah didefinisikan di aws-awos.js dan isinya lebih dari 1
        if (typeof historyAWS !== 'undefined' && historyAWS.length > 5) {
            console.log("QAM: History loaded, correcting sensor data...");
            updateQAMSensor(); // Koreksi data
            clearInterval(checkHistoryLoaded); // Stop checking
        }
        
        // Stop mencoba setelah 10 detik agar tidak memakan memori
        if (retryCount > 10) clearInterval(checkHistoryLoaded);
    }, 1000); 
}

/**
 * Fungsi Utama: Mencari Data Sensor
 */
function updateQAMSensor() {
    const dateVal = document.getElementById('qam-date').value;
    const timeVal = document.getElementById('qam-time').value;
    
    if (!dateVal || !timeVal) return;

    // Target waktu (UTC) yang dipilih user
    const targetTs = new Date(`${dateVal}T${timeVal}:00Z`).getTime();

    // Fungsi pencari data terdekat
    function findClosestData(historyList) {
        if (!historyList || !Array.isArray(historyList) || historyList.length === 0) return null;
        
        let closest = null;
        let minDiff = Infinity; 
        
        historyList.forEach(item => {
            const itemTs = new Date(item.timestamp.replace(" ", "T") + "Z").getTime();
            const diff = Math.abs(targetTs - itemTs);
            
            if (diff < minDiff) { 
                minDiff = diff; 
                closest = item; 
            }
        });
        
        return closest;
    }

    // Ambil data dari variabel global di aws-awos.js
    const listAwos = (typeof historyAWOS !== 'undefined') ? historyAWOS : [];
    const listAws = (typeof historyAWS !== 'undefined') ? historyAWS : [];

    const dataAwos = findClosestData(listAwos);
    const dataAws = findClosestData(listAws);

    // -- ISI DATA AWOS --
    if (dataAwos) {
        document.getElementById('qam-wind-dir').value = dataAwos.awos_winddir || '';
        document.getElementById('qam-wind-spd').value = dataAwos.awos_winds || '';
        document.getElementById('qam-temp').value = dataAwos.awos_temp || '';
        document.getElementById('qam-dew').value = dataAwos.awos_dp || '';
    } else {
        // Kosongkan jika tidak ada data history sama sekali
        // (Opsional: bisa dikasih value '-' biar user tahu data belum siap)
    }

    // -- ISI DATA AWS --
    if (dataAws) {
        document.getElementById('qam-rh').value = dataAws.aws_rh || '';
        // Bersihkan data MSLP/QNH dari karakter non-angka
        document.getElementById('qam-qnh').value = dataAws.aws_mslp ? dataAws.aws_mslp.replace(/[^\d.-]/g, '') : '';
    }
}

/**
 * Tombol FETCH: Mengambil ulang data sesuai jam yang dipilih
 * (Menggantikan fungsi Reset)
 */
function refreshSensorData() {
    // Kita tidak mereset tanggal/jam ke 'now'.
    // Kita hanya memanggil ulang updateQAMSensor.
    // Ini akan menimpa editan manual user dengan data asli dari database/json.
    
    const btn = document.querySelector('button[onclick="refreshSensorData()"] i');
    if(btn) btn.classList.add('animate-spin'); // Efek putar icon sebentar
    
    updateQAMSensor();

    setTimeout(() => {
        if(btn) btn.classList.remove('animate-spin');
    }, 500);
}

/**
 * Cek Gambar Bukti
 */
function checkImageFromQAM(type) {
    const dateVal = document.getElementById('qam-date').value;
    const timeVal = document.getElementById('qam-time').value;
    if (!dateVal || !timeVal) return alert("Mohon isi Tanggal dan Jam (UTC) di form QAM terlebih dahulu.");

    const targetTs = new Date(`${dateVal}T${timeVal}:00Z`).getTime();
    
    const list = (type === 'aws') ? 
                 (typeof historyAWS !== 'undefined' ? historyAWS : []) : 
                 (typeof historyAWOS !== 'undefined' ? historyAWOS : []);

    if (list.length === 0) return alert("Data History belum dimuat atau kosong.");

    let closest = null, minDiff = Infinity;

    list.forEach(item => {
        const itemTs = new Date(item.timestamp.replace(" ", "T") + "Z").getTime();
        const diff = Math.abs(targetTs - itemTs);
        if (diff < minDiff) { minDiff = diff; closest = item; }
    });

    if (closest && closest.original_image) {
        document.getElementById('modalImage').src = closest.original_image;
        document.getElementById('modalTitle').innerText = `Capture ${type.toUpperCase()}: ${closest.timestamp}`;
        document.getElementById('imgPathDisplay').innerText = closest.original_image;
        document.getElementById('imageModal').classList.remove('hidden');
    } else {
        alert(`Gambar ${type.toUpperCase()} tidak ditemukan.`);
    }
}

/**
 * Generate Text Laporan
 */
function generateQAM() {
    const inputs = {};
    const ids = ['qam-observer', 'qam-date', 'qam-time', 'qam-vis', 'qam-wx', 'qam-cloud', 'qam-trend', 'qam-supp', 'qam-wind-dir', 'qam-wind-spd', 'qam-temp', 'qam-dew', 'qam-rh', 'qam-qnh'];
    let isEmpty = false;
    
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (!el.value.trim()) {
            el.classList.add('ring-2', 'ring-red-500'); 
            isEmpty = true;
        } else {
            el.classList.remove('ring-2', 'ring-red-500');
            inputs[id] = el.value.trim();
        }
    });

    if (isEmpty) return alert("Mohon lengkapi semua data.");

    const stateData = {};
    ['observer', 'vis', 'wx', 'cloud', 'trend', 'supp'].forEach(k => stateData[k] = inputs['qam-' + k]);
    fetch('save_qam_state.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(stateData) }).catch(e => console.error(e));

    const qnhVal = parseFloat(inputs['qam-qnh']);
    const qfeVal = qnhVal - 0.9; 
    const [y, m, d] = inputs['qam-date'].split('-');
    
    const finalMessage = `Weather Utarom Airport - ${d}/${m}/${y}\n\n👨🏽‍💻🛬 🛫 >>> 🌏☁\nReport = MET REPORT\nTime = ${inputs['qam-time'].replace(':', '.')} UTC\nWind = ${inputs['qam-wind-dir']}/${inputs['qam-wind-spd']} KT\nVis      =  ${inputs['qam-vis']} KM\nPresent Wx = ${inputs['qam-wx']}\nCloud  = ${inputs['qam-cloud']}\nTT    = ${inputs['qam-temp']}°C\nTD    = ${inputs['qam-dew']}°C\nRH    = ${inputs['qam-rh']} %\nQNH = ${qnhVal.toFixed(1)} mb - ${(qnhVal * 0.02953).toFixed(2)} inch\nQFE   = ${qfeVal.toFixed(1)} mb - ${(qfeVal * 0.02953).toFixed(2)} inch\nTREND = ${inputs['qam-trend']}\nSupp Info = ${inputs['qam-supp']}\n\nBy: Observer on Duty ${inputs['qam-observer']}`;

    document.getElementById('qam-result').value = finalMessage;
}

/**
 * Kirim ke Server & Copy
 */
async function sendAndCopyQAM() {
    const textArea = document.getElementById("qam-result");
    const messageVal = textArea.value;
    const btn = document.getElementById('btn-send-qam');
    if (!messageVal) return alert("Generate pesan terlebih dahulu!");

    textArea.select();
    try { navigator.clipboard.writeText(messageVal); } catch (e) {}

    const originalText = btn.innerHTML;
    btn.innerHTML = 'Sending...';
    btn.disabled = true;

    try {
        const formData = new FormData();
        formData.append('message', messageVal);
        const response = await fetch('save_qam.php', { method: 'POST', body: formData });
        const result = await response.json();

        if (response.ok && result.status === 'success') {
            btn.innerHTML = 'Sent!';
            document.getElementById('copy-status').innerText = "Terkirim ke Server!";
            document.getElementById('copy-status').style.opacity = '1';
        } else {
            alert("GAGAL KIRIM: " + result.msg);
        }
    } catch (error) {
        alert("NETWORK ERROR.");
    } finally {
        setTimeout(() => {
            btn.innerHTML = originalText;
            btn.disabled = false;
            document.getElementById('copy-status').style.opacity = '0';
            if(typeof lucide !== 'undefined') lucide.createIcons();
        }, 2000);
    }
}