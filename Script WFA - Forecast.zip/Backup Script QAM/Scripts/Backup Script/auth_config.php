<?php
session_start();

// --- KONFIGURASI ---
// Ganti password ini!
define('ADMIN_PASSWORD', 'senjakaimana'); 

// File untuk menyimpan ID sesi terakhir yang valid
define('SESSION_FILE', 'current_session.token');

function checkLoginStatus() {
    // 1. Cek apakah user punya sesi di browser
    if (!isset($_SESSION['login_token'])) {
        return false;
    }

    // 2. Cek apakah token di browser SAMA dengan token di server (file)
    if (file_exists(SESSION_FILE)) {
        $server_token = file_get_contents(SESSION_FILE);
        if ($_SESSION['login_token'] === $server_token) {
            return true; // Token cocok, user ini yang sah
        }
    }

    return false; // Token beda, berarti sudah ada user lain login (terkick)
}
?>