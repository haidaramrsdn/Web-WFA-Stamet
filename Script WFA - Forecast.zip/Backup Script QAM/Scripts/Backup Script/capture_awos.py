import pyautogui
import os
import time
from datetime import datetime, timedelta
from PIL import ImageChops  # Library untuk menggabungkan gambar

# --- KONFIGURASI ---
OUTPUT_FOLDER = r"F:\Data AWS AWOS\AWOS\images"
PREFIX_FILE = "awos"

# Interval capture dalam menit
INTERVAL_MINUTES = 2 

# --- KOMPENSASI WAKTU ---
# PC terlambat 160 detik.
OFFSET_SECONDS = 160 

def take_composite_screenshot(custom_time):
    """
    Mengambil 2 screenshot dengan jeda untuk mengatasi teks berkedip (blinking).
    Menggabungkan (merge) keduanya agar teks yang hilang di salah satu frame tetap muncul.
    """
    try:
        if not os.path.exists(OUTPUT_FOLDER):
            os.makedirs(OUTPUT_FOLDER)

        # Nama file menggunakan waktu yang sudah di-offset
        timestamp = custom_time.strftime("%Y%m%d_%H%M%S")
        filename = f"{PREFIX_FILE}_{timestamp}.png"
        full_path = os.path.join(OUTPUT_FOLDER, filename)
        
        # --- SHOT 1 ---
        # Ambil gambar pertama
        img1 = pyautogui.screenshot()
        
        # --- JEDA ANTAR SHOT ---
        # Tunggu 0.6 detik. 
        # Jika display berkedip 1 detik (0.5s ON / 0.5s OFF),
        # jeda 0.6s menjamin kita mendapatkan fase sebaliknya.
        time.sleep(0.6) 
        
        # --- SHOT 2 ---
        # Ambil gambar kedua
        img2 = pyautogui.screenshot()

        # --- MERGE (GABUNGKAN) ---
        # Membandingkan img1 dan img2. 
        # Karena background hitam (nilai 0), maka teks berwarna (nilai >0) 
        # akan selalu dipilih sebagai hasil akhir.
        final_image = ImageChops.lighter(img1, img2) 

        # Simpan hasil gabungan
        final_image.save(full_path)
        print(f"[SUCCESS] Saved Image: {filename}")
        
    except Exception as e:
        print(f"[ERROR] {e}")

def main():
    print(f"--- Service Berjalan: Anti-Blink Mode (Capture per {INTERVAL_MINUTES} menit) ---")
    print(f"--- Kompensasi Waktu: {OFFSET_SECONDS} detik ---")
    
    while True:
        now = datetime.now()
        
        # 1. CARI TARGET WAKTU BERIKUTNYA
        minutes_to_next_trigger = INTERVAL_MINUTES - (now.minute % INTERVAL_MINUTES)
        target_pc_time = now + timedelta(minutes=minutes_to_next_trigger)
        target_pc_time = target_pc_time.replace(second=0, microsecond=0)
        
        # 2. HITUNG KAPAN HARUS BANGUN (WAKTU PC - OFFSET)
        real_trigger_time = target_pc_time - timedelta(seconds=OFFSET_SECONDS)
        
        # Pastikan trigger ada di masa depan
        while real_trigger_time <= datetime.now():
            real_trigger_time += timedelta(minutes=INTERVAL_MINUTES)

        # 3. HITUNG DURASI TIDUR
        seconds_to_sleep = (real_trigger_time - datetime.now()).total_seconds()
        
        if seconds_to_sleep < 0: seconds_to_sleep = 1 

        print(f"Next Capture Process: {real_trigger_time.strftime('%H:%M:%S')} | Sleep: {int(seconds_to_sleep)}s")

        # Tidur...
        time.sleep(seconds_to_sleep)
        
        # 4. BANGUN & SIAPKAN NAMA FILE
        # Kita ambil waktu saat ini (saat bangun) lalu tambah offset
        current_pc_time = datetime.now()
        file_timestamp = current_pc_time + timedelta(seconds=OFFSET_SECONDS)
        
        # Eksekusi Screenshot Anti-Kedip
        take_composite_screenshot(file_timestamp)
        
        # Tidur sebentar agar aman
        time.sleep(10)

if __name__ == "__main__":
    main()