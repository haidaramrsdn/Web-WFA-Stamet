<?php
require 'auth_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass = $_POST['password'] ?? '';
    
    if ($pass === ADMIN_PASSWORD) {
        // Generate Token Baru
        $newToken = bin2hex(random_bytes(32));
        
        // Simpan token ke file server (ini akan meng-overwrite sesi lama/kick user lama)
        file_put_contents(SESSION_FILE, $newToken);
        
        // Simpan token ke sesi browser user ini
        $_SESSION['login_token'] = $newToken;
        
        header('Location: index.php');
        exit;
    } else {
        $error = "Password Salah!";
    }
}
?>


<?php if ($pesan_kick): ?>
    <div class="bg-yellow-100 text-yellow-800 p-3 rounded text-sm mb-4 text-center border border-yellow-200">
        <strong>Logout Otomatis</strong><br>
        <?= $pesan_kick ?>
    </div>
<?php endif; ?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Stasiun Meteorologi Kaimana</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 h-screen flex items-center justify-center p-4">
    <div class="bg-white p-8 rounded-xl shadow-xl w-full max-w-sm border border-slate-200">
        <div class="text-center mb-6">
            <img src="web_assets/bmkg-logo.png" alt="BMKG" class="h-16 mx-auto mb-4">
            <h1 class="text-xl font-bold text-slate-700">Limited Access</h1>
            <p class="text-xs text-slate-400 mt-1">Single Session</p>
        </div>

        <?php if(isset($error)): ?>
            <div class="bg-red-100 text-red-700 p-3 rounded text-sm mb-4 text-center font-bold">
                <?= $error ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-4">
                <label class="block text-sm font-bold text-slate-600 mb-2">Password</label>
                <input type="password" name="password" required class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition">
            </div>
            <button type="submit" class="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition shadow-lg active:scale-95">
                Login
            </button>
        </form>
    </div>
</body>
</html>