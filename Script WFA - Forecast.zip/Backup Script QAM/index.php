<?php 
require 'auth_config.php';

// Jika tidak punya akses, lempar ke login
if (!checkLoginStatus()) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stasiun Meteorologi Kaimana</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    colors: {
                        bmkg: '#0056b3',
                        awosBg: '#e2e8f0',
                        awosDark: '#cbd5e1',
                    }
                }
            }
        }
    </script>
    
    <style>
        body { background-color: #f4f6f9; }
        
        .value-box {
            background: #ffffff;
            border: 1px solid #cbd5e1;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.06);
            font-family: 'JetBrains Mono', monospace;
            font-size: 1.5rem; 
            font-weight: 500;
            color: #1e293b;
            line-height: 2rem;
            min-width: 85px; 
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .updated { animation: highlight 1s ease-out; }
        @keyframes highlight { 0% { background-color: #fef08a; } 100% { background-color: #ffffff; } }

        .data-item { display: flex; align-items: center; justify-content: flex-end; gap: 0.75rem; }
        .label-text { font-size: 1.15rem; font-weight: 600; color: #64748b; text-align: right; white-space: nowrap; letter-spacing: -0.01em; }
        
        /* Hack input date transparan (Dashboard Utama) */
        #date-aws-input::-webkit-calendar-picker-indicator,
        #date-awos-input::-webkit-calendar-picker-indicator { 
            background: transparent; bottom: 0; color: transparent; cursor: pointer; height: auto; left: 0; position: absolute; right: 0; top: 0; width: auto; 
        }
        
        /* Pastikan icon kalender pada Modal tetap terlihat normal */
        #exp-start::-webkit-calendar-picker-indicator,
        #exp-end::-webkit-calendar-picker-indicator {
            cursor: pointer;
            filter: invert(0.4);
        }

        .tab-active { background-color: #0056b3; color: white; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
        .tab-inactive { background-color: #f1f5f9; color: #475569; }
        .tab-inactive:hover { background-color: #e2e8f0; }

        .nav-btn { cursor: pointer; font-weight: 700; display: flex; align-items: center; gap: 0.25rem; font-size: 0.875rem; transition: color 0.2s; }
        .nav-btn:hover { text-decoration: underline; }
    </style>
</head>
<body class="p-4 md:p-8 min-h-screen text-slate-800">

    <div id="imageModal" class="fixed inset-0 z-50 hidden flex items-center justify-center bg-black/80 backdrop-blur-sm p-4" onclick="closeModal()">
        <div class="bg-white rounded-lg overflow-hidden max-w-5xl w-full shadow-2xl relative flex flex-col max-h-[90vh]" onclick="event.stopPropagation()">
            <div class="flex justify-between items-center p-3 border-b bg-slate-50">
                <h3 class="text-lg font-bold text-slate-700 flex items-center gap-2">
                    <i data-lucide="image"></i> <span id="modalTitle">Bukti Capture</span>
                </h3>
                <button onclick="closeModal()" class="p-1 hover:bg-red-100 rounded-full hover:text-red-600 transition"><i data-lucide="x"></i></button>
            </div>
            <div class="p-1 bg-slate-200 flex-1 flex justify-center overflow-auto">
                <img id="modalImage" src="" alt="Loading..." class="max-w-full object-contain">
            </div>
            <div class="p-2 bg-white text-xs text-center text-slate-400 font-mono" id="imgPathDisplay"></div>
        </div>
    </div>

    <div id="exportModal" class="fixed inset-0 z-[999] hidden flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 transition-opacity">
        <div class="bg-white rounded-xl p-6 max-w-md w-full shadow-2xl relative border border-slate-200 transform transition-all scale-100">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <i data-lucide="database"></i> Ekstrak Data
                    <span id="exportTarget" class="uppercase text-xs font-black bg-blue-100 text-blue-700 px-2 py-1 rounded ml-2">AWS</span>
                </h3>
                <button id="btnCloseModalX" class="text-slate-400 hover:text-red-500 transition-colors p-1">
                    <i data-lucide="x"></i>
                </button>
            </div>
            
            <p class="text-sm text-slate-500 mb-4 bg-slate-50 p-3 rounded border border-slate-200">
                Pilih rentang waktu (UTC). <br>
                <span class="text-xs text-orange-600 font-bold">*Rentang waktu panjang butuh proses lebih lama.</span>
            </p>

            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Waktu Mulai (UTC)</label>
                    <input type="datetime-local" id="exp-start" class="export-date-input w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-bmkg outline-none text-slate-700 font-mono text-sm bg-white shadow-sm cursor-pointer">
                </div>
                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Waktu Selesai (UTC)</label>
                    <input type="datetime-local" id="exp-end" class="export-date-input w-full border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-bmkg outline-none text-slate-700 font-mono text-sm bg-white shadow-sm cursor-pointer">
                </div>
            </div>

            <div class="mt-8 flex gap-3">
                <button id="btnCancelModal" class="flex-1 py-3 font-bold text-slate-600 hover:bg-slate-100 rounded-lg border border-slate-300 transition-all">
                    Batal
                </button>
                <button onclick="doExport()" class="flex-[2] py-3 font-bold text-white bg-green-600 hover:bg-green-700 rounded-lg shadow-lg flex justify-center items-center gap-2 transition-all active:scale-95">
                    <i data-lucide="download" class="w-4 h-4"></i> Download CSV
                </button>
            </div>
        </div>
    </div>

    <header class="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-6 flex flex-col md:flex-row items-center justify-between gap-4 max-w-7xl mx-auto">
        <div class="flex items-center gap-6">
            <div class="w-16 h-16 shrink-0">
                <img src="web_assets\bmkg-logo.png" alt="Logo BMKG" class="w-full h-full object-contain">
            </div>
            <h1 class="text-xl font-bold hidden md:block text-slate-700 uppercase tracking-wider">
                Support System
            </h1>
        </div>

        <nav class="flex flex-wrap justify-center gap-2">
            <button onclick="switchTab('main')" id="btn-main" class="tab-active px-5 py-2 rounded-full font-bold text-sm transition-all transform active:scale-95">AWS & AWOS</button>
            <button onclick="switchTab('visibility')" id="btn-visibility" class="tab-inactive px-5 py-2 rounded-full font-bold text-sm transition-all">Visibility</button>
            <button onclick="switchTab('me48')" id="btn-me48" class="tab-inactive px-5 py-2 rounded-full font-bold text-sm transition-all">ME48/45</button>
            <button onclick="switchTab('forecast')" id="btn-forecast" class="tab-inactive px-5 py-2 rounded-full font-bold text-sm transition-all">Forecast</button>
            <button onclick="switchTab('qam')" id="btn-qam" class="tab-inactive px-5 py-2 rounded-full font-bold text-sm transition-all">QAM</button>
        </nav>

        <div class="flex flex-col items-end justify-center text-right">
            <div id="top-date" class="text-sm font-bold text-slate-500 mb-0.5 tracking-wide">...</div>
            <div id="top-clock" class="text-xl font-mono font-extrabold text-slate-800 leading-none flex items-center gap-2">...</div>
        </div>
    </header>

    <main id="content-main" class="flex flex-col gap-8 max-w-7xl mx-auto">
        <?php include 'modules/aws.php'; ?>
        <?php include 'modules/awos.php'; ?>
		
    </main>
	
	<?php include 'modules/forecast.php';?>
    
    <?php include 'modules/qam.php'; ?>

    <main id="content-blank" class="hidden max-w-7xl mx-auto min-h-[500px] flex items-center justify-center">
        <div class="text-center p-12 bg-white rounded-xl shadow-lg border border-slate-200">
            <h2 id="blank-title" class="text-4xl font-black text-slate-300 mb-4">Coming Soon</h2>
            <p class="text-slate-500 text-lg">Halaman ini sedang dalam pengembangan.</p>
        </div>
    </main>


	
	<script src="assets/js/core.js?v=999"></script>
    <script src="assets/js/aws-awos.js?v=999"></script>
    <script src="assets/js/qam.js?v=999"></script>
	<script src="assets/js/forecast.js?v=1"></script>


</body>
</html>