<?php
require 'auth_config.php';

header('Content-Type: application/json');

if (checkLoginStatus()) {
    echo json_encode(['status' => 'active']);
} else {
    // Hapus sesi browser jika tidak valid
    session_destroy();
    echo json_encode(['status' => 'kicked']);
}
?>